<?php
class Material extends AppModel
{
	var $name='Material';
	var $useTable='materiales';
}
?>
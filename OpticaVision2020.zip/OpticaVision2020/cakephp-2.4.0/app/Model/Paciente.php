<?php
class Paciente extends AppModel{
	//se realizan todas las validaciones no permitidas en el modelo
	var $name = 'Paciente';
	//var $hasOne='Record';

	var $hasOne = array(
			'Record' => array(
					'className'=>'Record'
			)
	);
	var $hasMany = array(
			'Venta'=>array(
					'className'=>'Venta'),
			'Graduation' => array(
					'className'=>'Graduation'
			)
	);
	//var $hasOne = 'Record';
	//var $hasOne = 'Graduation';
	//public $displayField = 'Nombre';
	
	//validando que los datos
	public $validate = array(
			'Nombre_completo'=>array(
					'Not Empty.'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el nombre completo del paciente.'
					)
			),
			'Domicilio'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el domicilio del paciente.'
					)
			),
			'Telefono' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el tel�fono del paciente'
					)
			),
			'Ciudad' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la ciudad del paciente'
					)
			),
			'Estado' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el estado del paciente'
					)
			),
			'Edad' => array(
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese  ingrese la edad del paciente.'
					),
					'rango' => array(
							'rule' => array('range',0,250),
							'message' => 'Se ha excedido del rango permitido, ingrese un valor de 0 a 250'
		  		 ),
			),
			'Genero' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el g�nero del paciente.'
					)
			),
			'Fecha_nac' => array(
					
					'fechaValida' => array(
							
							'rule' => 'date',
							'message' => 'Ingrese una fecha de nacimiento v�lida'
					)
			),
			'Not empty'=>array(
					'Not Empty' => array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de nacimiento del paciente.'
			)
		)
	);
}
?>
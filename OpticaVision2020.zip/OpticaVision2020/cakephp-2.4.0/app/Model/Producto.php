<?php
class Producto extends AppModel
{
	var $name='Producto';
	var $hasMany=array(
			'DetalleVenta'=>array(
					'className'=>'DetalleVenta'
				)
			);
	var $belongsTo='Suplier';
	var $validate = array(
		   'Nombre'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el nombre del producto.'
					)
			),
			'Descripcion'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la descripci�n del producto.'
					)
			),
			'Marca'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la Marca del producto.'
					)
			),
			'Caracteristica'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese las caracter�sticas del producto.'
					)
			),
			'Cantidad'=>array(
				
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la cantidad de productos disponible.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
				
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					),
			),
			'Cantidad_min'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la cantidad m�nima de productos.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea n�merico'
					),
					/*
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					),*/
			),
			'Precio_compra'=>array(
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el precio de compra del producto'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					),
				
			),
			'Precio_venta'=>array(
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el precio de venta del producto'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					),
				
			),	
		
			'Fecha' => array(
					'date' => array(
							//Add 'ymd' to the rule.
							'rule' => array('date', 'ymd'),
							'message' => 'Por favor selecciona una fecha v�lida.',
					),
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha.'
					)
			),
			'Suplier_id'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el proveedor.'
					)
			),
	);

	
}
?>
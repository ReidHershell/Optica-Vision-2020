<?php
//App::uses('AuthComponent', 'Controller/Component');
class Graduation extends AppModel{
	var $name = 'Graduation';
	var $useTable='graduaciones';
	//var $displayField = 'Nombre';

	var $belongsTo = array(
			'Paciente'=>array(
					'className'=>'Paciente'
			)
	);
	//validando que los datos
	public $validate = array(
			'D_i_p' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el D.I.P. del paciente.'
					)
			),
			'Fecha_registro'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de registro de la graduaci�n.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
			),
			'Avsc_o_d'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el A.V.sc del O.D del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Avcc_o_d' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el A.V.cc del O.D del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_i_avcc_o_d'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el O.I A.V.cc O.D del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Aeo_d' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el A.E.O.D del paciente'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Av_cerca_o_d' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la A.V. de cerca del O.D. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Oi_av_cerca' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la A.V. de cerca del O.I. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_d_queratometria' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la queratometr�a del O.D. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_i_queratometria' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la queratometr�a del O.I. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_d_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la Graduaci�n nueva en el O.D. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_d_av_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la A.V. del O.D. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_d_adic_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la Adic. del O.D. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_i_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la graduaci�n del O.I. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_i_av_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la A.V. del O.I. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'O_i_adic_gradnueva' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la Adic. del O.I. del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			
			'Alt_oblea' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la Alt. de Oblea del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Tinte' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el tinte.'
					)
			),
			'Material' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el material.'
					)
			),
			'Armazon' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el armaz�n.'
					)
			),
			'Lentes_contacto' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la descripci�n de los lentes de contacto.'
					)
			),

	);
}
?>
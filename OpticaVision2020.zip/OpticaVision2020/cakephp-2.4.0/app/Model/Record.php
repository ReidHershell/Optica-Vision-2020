<?php
class Record extends AppModel
{
	var $name='Record';
	var $useTable='historiales';

	
	var $belongsTo = array(
			'Paciente'=>array(
			'className'=>'Paciente'
		)
	);
	//var $displayField = 'Fecha_registro';
	//validando que los datos
	public $validate = array(
			'Fecha_registro'=>array(
					'Not Empty.'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de registro del historial.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha de registro de historial v�lida',
					),
			),
			'Claridad_deseable' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Indica si el paciente tiene claridad deseable'
					),
			),
			'Fatiga_ocular'=>array(
						'Not Empty'=>array(
								'rule'=>'notEmpty',
								'message' => 'Indica si el paciente tiene fatiga ocular'
						),
							
			),
			'Necesidad_visual' => array(	
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Indica las necesidades visuales del paciente'
						),			
			),
			'Molestia_luz_sol' => array(
						'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Indica si al paciente le molesta la luz solar'
						),
						
			),
			'Fecha_ult_ex' => array(
							'Not Empty.'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha del �ltimo examen que present� el paciente.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
					
			),
			'Lugar_ult_ex' => array(
							'Not empty'=>array(
								'rule'=>'notEmpty',
								'message'=>'Indica el lugar del ultimo examen que present� el paciente'
			   	 	)
					
			),
			'Usa_anteojos' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica si el paciente usa o ha usado anteojos'
			    	),
					
			),
					/*
			'Tiempo_lentes' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indique el tiempo que el paciente tiene usando lentes'
			    ),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea numerico'
					)
						
			),*/
			/*
			'Prob_con_lentes' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indique los problemas que ha presentado el paciente al usar lentes'
			    ),
						
			),*/
			'Usado_parche' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica si el paciente ha usado parche en el ojo.'
			    ),
							
			),
			/*
			'Porque_usa_parche' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica la razon por la que le paciente ha usado parche en el ojo.'
			    ),
			),*/
			'Infecciones_oculares' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica si el paciente presenta infecciones oculares'
			    ),
			),
			'Fecha_ul_ex_fisico' => array(
							'Not Empty.'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha del �ltimo examen f�sico que present� el paciente.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
			),
			'Diab_hiper_otra' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica si el paciente ha padecido de diabetes, hipertensi�n arterial u otra '
			    )
			),
				
			'Alergias' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indique las alergias que ha presentado el paciente en caso de tenerlas'
			    ),
			),
			'Fam_cat_glu_ceg' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indique si alg�n familiar del paciente o el paciente han tenido cataratas, glucosa o ceguera'
			    )
			),
			'Fam_diab_hip' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica si alg�n familiar del paciente han padecido de diabetes o hipertensi�n arterial  '
			    )
			),
					/*
			'Edad_diab_hip' => array(
							'Not empty'=>array(
									'rule'=>'notEmpty',
									'message'=>'Indica la edad en la que algun familiar padecieron de diabetes o hipertensi�n arterial en caso de haber padecido'
			   ),
							'contieneValor' => array(
									'rule'    => 'numeric',
									'message' => 'Se requiere que el campo sea num�rico'
							),
							'rango' => array(
									'rule' => array('range',0,250),
									'message' => 'Se ha excedido del rango permitido, ingrese un valor de 0 a 250'
						)
			),*/
			'Supo_nosotros' => array(
						'Not empty'=>array(
								'rule'=>'notEmpty',
								'message'=>'Indica como el paciente supo de nosotros'
			
			),
		)
	);

}
?>
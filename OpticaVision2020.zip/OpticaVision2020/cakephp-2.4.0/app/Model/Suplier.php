<?php
class Suplier extends AppModel
{
	//se realizan todas las validaciones no permitidas en el modelo
	var $name = 'Suplier';

	var $hasMany = 'Producto';
	//validando que los datos
	public $validate = array(
			'Nombre_completo'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el nombre completo del proveedor.'
					)
			),
			'Domicilio'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el domicilio del proveedor.'
					)
			),
			'Email' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la direcci�n de email del proveedor'
					),
			'email_valido'=>array(
							'rule'=>array('email'),
							'message'=>'Por favor ingresa una direcci�n de email v�lida.'
					),
			),
			'Telefono' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el tel�fono del proveedor'
					)
			),
			'Ciudad' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la ciudad del proveedor'
					)
			),
			'Estado' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el estado del proveedor'
					)
			),
			
	);
}
?>
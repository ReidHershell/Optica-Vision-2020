<?php
class DetalleVenta extends AppModel
{
	var $name='DetalleVenta';
	var $useTable='detalle_ventas';

	var $belongsTo=array(
			'Producto'=>array(
					'className'=>'Producto'
			),
			'Venta'=>array(
					'className'=>'Venta'
			)
	);

	public $validate = array(	
			'producto_id' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que seleccione el producto.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Cantidad' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese la cantidad de productos.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			
			'venta_id' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el No. de venta correspondiente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			
	);
}
?>

<?php
App::uses('AuthComponent', 'Controller/Component');
class User extends AppModel{
	var $hasMany = array(
			'Venta'=>array(
					'className'=>'Venta'));
	//se realizan todas las validaciones no permitidas en el modelo
	public $validate = array(
		'Nombre_completo'=>array(
			'Not Empty'=>array(
				'rule'=>'notEmpty',
				'message'=>'Se requeire que ingrese su nombre completo.'
			)
		),
		'username'=>array(
			'Not Empty'=>array(
					'rule'=> 'notEmpty',
					'message'=>'Se requeriere que ingrese su nombre de usuario.'
			),
			'longitud'=>array(
				'rule'=>array('between', 5, 15),
				'message'=>'El nombre de usuario debe tener entre 5 y 15 caracteres.'
			),
		),
		'Email'=>array(
			'Not Empty'=>array(
					'rule'=> 'notEmpty',
					'message'=>'Se requiere que ingrese su direcci�n de email.'
			),
			'email_valido'=>array(
				'rule'=>array('email'),
				'message'=>'Por favor ingresa una direcci�n de email v�lida.'
			),
		),
		'password'=>array(
		    'Not Empty'=>array(
		        'rule'=>'notEmpty',
		        'message'=>'Se requiere que ingrese una contrase�a'
		),
		'longitud' => array(
					'rule'  => array('minLength', '5'),
					'message' => 'La contrase�a debe contener al menos 5 caracteres'
		),
			
		   'Match passwords'=>array(
		        'rule'=>'matchPasswords',
		        'message'=>'Las contrase�as no coinciden'
		    )
		),
			
		'password_confirmation'=>array(
		    'Not Empty'=>array(
		        'rule'=>'notEmpty',
		        'message'=>'Por favor confirma tu contrase�a'
		    )
		),
		'Palabra_secreta' => array(
				'Not Empty' => array(
						'rule' => 'notEmpty',
						'message' => 'Se requiere que ingrese su palabra secreta '
				)
		),
		'Domicilio' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su domicilio'
			)
		),
		'Telefono' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su tel�fono'
			)
		),
		'Edad' => array(
			'contieneValor' => array(
				'rule'    => 'numeric',
				'message' => 'Se requiere que el campo sea num�rico'
			),
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su edad'
			),
			'rango' => array(
				'rule' => array('range',0,250),
				'message' => 'Se ha excedido del rango permitido, ingrese un valor de 0 a 250'
		   ),
		),
		'Ciudad' => array(
				'Not Empty' => array(
					'rule' => 'notEmpty',
					'message' => 'Se requiere que ingrese su ciudad'
				)
		),
		'Estado' => array(
				'Not Empty' => array(
						'rule' => 'notEmpty',
						'message' => 'Se requiere que ingrese su estado'
				)
		),
		'Genero' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su g�nero'
				)
		),
		'Puesto' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su puesto'
				)
		),
		'Rol' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su rol'
			)
		),
		'Salario' => array(
			'contieneValor' => array(
					'rule'    => 'numeric',
					'message' => 'Se requiere que el campo sea num�rico'
			),
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su salario'
			),
		'rango' => array(
				'rule' => array('range',0,100000000),
				'message' => 'No se permiten valores negativos'
		   ),
		),
		'Rfc' => array(
			'Not Empty' => array(
				'rule' => 'notEmpty',
				'message' => 'Se requiere que ingrese su RFC'
			)
		)
	);

	//Funcion que evalua si dos contrase�as coinciden
	public function matchPasswords($data) {
		if($data['password'] == $this->data['User']['password_confirmation']) {
			return true;
		}
		else
		{
			//se invallida el campo y se muestra el mesaje del campo invalido de que las contrase�as no coinciden
			$this->invalidate('password_confirmation','Las contrase�as no coinciden');
			return false;
		}
	}	

	//Funcion que encripta la contrase�a antes de guardarla
	public function beforeSave($options = array()) 
	{
		if (isset($this->data['User']['password'])) //se obtiene la contrase�a del usuario que se quiere guardar
		{
			//una vez que se obtiene la contrase�a del usuario que se quiere guardar se encrita 
			$this->data['User']['password'] = AuthComponent::password($this->data['User']['password']);
		}
		return true;
	}

}
?>

<?php
class Accesorio extends AppModel
{
	var $name='Accesorio';
	//public $useTable='materiales';
}
?>

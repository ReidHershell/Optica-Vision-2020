<?php
class Anticipo extends AppModel
{
	var $name='Anticipo';
	var $belongsTo =array(
			'Venta'=>array(
					'className'=>'Venta'
			)
	);
	public $validate = array(
			'fecha'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de registro.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
			),	
			'Saldo_anterior' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el saldo anterior del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'pago' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el pago que realizar� el paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Estado_cuenta' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el estado de cuenta del paciente.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'venta_id' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el n�mero de la venta correspondiente al anticipo que se realizar�.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			
	);
}
?>
<?php
class Venta extends AppModel
{
	var $belongsTo = array(
			'Paciente'=>array(
					'className'=>'Paciente'
			),
			'User' => array(
					'className'=>'User'
			)
	);
	var $hasMany = array(
			'DetalleVenta'=>array(
					'className'=>'DetalleVenta'
			),
			'Anticipo'=>array(
					'className'=>'Anticipo'
			)		
	);
	var $name='Venta';
	public $validate = array(
			'fecha'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de registro.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
			),
			'Tipo_pago' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que especifique el tipo de pago.'
					),
			),
			'Costo' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que especifique el precio total de la compra.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Liquidado' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que indique si esta liquidado el pago.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Actividad' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que especifique la actividad que se va a realizar.'
					)			
			),
			'user_id' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que indique el usuario que atendi�'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'paciente_id' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que indique el paciente que compra.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),				
	);
}
?>
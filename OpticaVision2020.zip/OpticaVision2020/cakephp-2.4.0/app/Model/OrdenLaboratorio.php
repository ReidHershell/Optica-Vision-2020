<?php
class OrdenLaboratorio extends AppModel
{
	var $name = 'OrdenLaboratorio';
	//var $displayField = 'Nombre';
	//validando que los datos
	public $validate = array(
			
			'Mica'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere los datos de la mica de los lentes'
					)
			),
			'Cristal'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese los datos del cristal de los lentes'
					)
				
			),
			'Caracteristicas' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese las caracter�sticas de los lentes.'
					)
			),
			'Fecha'=>array(
					'Not Empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la fecha de registro de la orden de laboratorio.'
					),
					'date' => array(
							'rule'       => 'date',
							'message'    => 'Ingresa una fecha v�lida',
					)
			),
			'Od_esf' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.D ESF de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Od_cil' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.D CIL de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Od_eje' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.D EJE de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Od_add' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la queratometr�a del O.D add de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Oi_esf' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.I ESF de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Oi_cil' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.I CIL de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Oi_eje' => array(
					'Not Empty' => array(
							'rule' => 'notEmpty',
							'message' => 'Se requiere que ingrese el O.I EJE de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),
			'Oi_add' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese la queratometr�a del O.I add de los lentes.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			),		
			'venta_id' => array(
					'Not empty'=>array(
							'rule'=>'notEmpty',
							'message'=>'Se requiere que ingrese el n�mero de venta correspondiente a la orden de laboratorio.'
					),
					'contieneValor' => array(
							'rule'    => 'numeric',
							'message' => 'Se requiere que el campo sea num�rico'
					),
					'rango' => array(
							'rule' => array('range',0,100000000),
							'message' => 'No se permiten valores negativos'
					)
			)	
	);
}
?>

$("#link-1478188521").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/graduations\/view\/1"});
return false;});
$("#link-1715687049").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/graduations\/edit\/1"});
return false;});
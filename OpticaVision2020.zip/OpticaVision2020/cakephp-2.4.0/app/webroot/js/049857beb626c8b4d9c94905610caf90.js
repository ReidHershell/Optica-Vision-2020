$("#link-343896241").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/records\/view\/4"});
return false;});
$("#link-240670879").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/records\/edit\/4"});
return false;});
$("#link-1065566518").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/pacientes\/Lista_pacientes\/4"});
return false;});
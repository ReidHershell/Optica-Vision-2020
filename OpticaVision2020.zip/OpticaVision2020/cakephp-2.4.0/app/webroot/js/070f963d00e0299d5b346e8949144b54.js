$(document).ready(function () {$("#link-1735887602").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/users\/view\/1"});
return false;});
$("#link-1953740519").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/users\/edit\/1"});
return false;});
$("#link-1100636374").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/users\/view\/2"});
return false;});
$("#link-748005214").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/users\/edit\/2"});
return false;});});
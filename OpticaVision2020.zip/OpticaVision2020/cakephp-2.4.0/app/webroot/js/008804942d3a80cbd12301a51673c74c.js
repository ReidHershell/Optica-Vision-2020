$("#submit-1521879325").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, data:$("#submit-1521879325").closest("form").serialize(), dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", type:"post", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/ventas\/index"});
return false;});
$("#link-984264650").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/ventas\/view"});
return false;});
$("#link-439853176").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/ventas\/view"});
return false;});
$("#link-1044014245").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/ventas\/view"});
return false;});
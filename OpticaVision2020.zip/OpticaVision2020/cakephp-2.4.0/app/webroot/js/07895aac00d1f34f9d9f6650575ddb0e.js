$("#link-352045066").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/DetalleVentas\/view\/1"});
return false;});
$("#link-692684537").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/DetalleVentas\/edit\/1"});
return false;});
$("#link-1026982132").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/ventas\/view\/7"});
return false;});
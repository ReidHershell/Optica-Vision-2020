$("#link-397222610").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/graduations\/view\/2"});
return false;});
$("#link-245015103").bind("click", function (event) {$.ajax({dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/graduations\/edit\/2"});
return false;});
$("#link-325538870").bind("click", function (event) {$.ajax({beforeSend:function (XMLHttpRequest) {$("#inprogress")}, dataType:"html", success:function (data, textStatus) {$("#sucess").html(data);}, sucess:"$(\"#inprogress\")", url:"\/workspace\/OpticaVision2020\/cakephp-2.4.0\/pacientes\/Lista_pacientes\/1"});
return false;});
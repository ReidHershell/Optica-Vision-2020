<?php
class AppPermissions extends Object {
   
    // Define the groups allowed, order matters
    var $groups = array("Author", "Admin");

    var $Users = array(
        "index" => "Author",
        "view"  => "Author",
        "add"   => "Admin",
        "edit"  => "Admin",
        "delete"=> "Admin"
    );

    var $Posts = array(
        "index" => "Author",
        "view"  => "Author",
        "add"   => "Admin",
        "edit"  => "Admin",
        "delete"=> "Admin"
    );

    function currentActionGroup($controller_name, $action) {
        if (!isset($this->{$controller_name})) return false;
        if (!isset($this->{$controller_name}[$action])) return false;
        return $this->{$controller_name}[$action];
    }

    function groupHasAccess($controller, $action, $group = "Author") {
        $group_index = array_search($group, $this->groups);
        $allowedGroup = $this->__currentActionGroup($controller, $action);
        $allowedGroup_index = array_search($allowedGroup, $this->groups);
   
        return $group_index >= $allowedGroup_index;
    }
}
?>
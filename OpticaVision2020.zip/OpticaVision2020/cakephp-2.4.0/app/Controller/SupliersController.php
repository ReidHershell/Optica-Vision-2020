<?php
class SupliersController extends AppController
{
	var $name = 'Supliers';
	var $components = array( 'RequestHandler' );
	//var $helpers = array('Js','Html', 'Form');
	public function beforeFilter() 
	{	
		parent::beforeFilter();	
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar
		
		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{		
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar		
			$this->Auth->allow('index','view','lista_proveedores');		
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar proveedores
				$this->Auth->allow('add','edit','delete');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{	
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' || $this->params['action']== 'add')
				{
					$this->Session->setFlash('No estas autorizado para realizar esta accion');
					$this->redirect(array('action'=>'lista_proveedores'));
				}			
			}
		}
		else
		{	
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}		
	}
	
	//Funcion que muestra la lista de proveedores registrados en el sistema
	public function index() {
		$this->Suplier->query('ALTER TABLE `supliers` AUTO_INCREMENT=1 ');
		$this->Suplier->recursive = 1;
		$proveedores=$this->paginate();

		//print_r($proveedor);
		//$this->set('supliers', $this->paginate());
	
		$this->set('proveedores', $proveedores);
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['Suplier']['buscar'];			
			if (!empty($buscar))
			{
				$buscar=$this->Suplier->find('all',array('conditions'=>array(
						'OR'=>array('Suplier.Nombre_completo LIKE'=>'%'.$buscar.'%','Suplier.Email'=>$buscar))
						)
				);

				if (count($buscar)>0)
				{
					$this->set('proveedores',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Suplier->invalidate('buscar','No se encontraron coincidencias de ese proveedor');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Suplier->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}
			$this->render('lista_proveedores','tabla');//se renderiza la vista index a otra vista
				
		}
	}
	//funcion que muestra la lista de proveedores
	public function lista_proveedores() {
		$this->layout='tabla';
		$this->Suplier->query('ALTER TABLE `supliers` AUTO_INCREMENT=1 ');
		$this->Suplier->recursive = 1;
		$proveedores=$this->paginate();
		$this->set('proveedores', $proveedores);
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['Suplier']['buscar'];			
			if (!empty($buscar))
			{
				$buscar=$this->Suplier->find('all',array('conditions'=>array(
						'OR'=>array('Suplier.Nombre_completo LIKE'=>'%'.$buscar.'%','Suplier.Email'=>$buscar))
						)
				);

				if (count($buscar)>0)
				{
					$this->set('proveedores',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Suplier->invalidate('buscar','No se encontraron coincidencias de ese proveedor');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Suplier->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}
			$this->render('lista_proveedores','tabla');//se renderiza la vista
				
		}
	}
	//Funcion que muestra la informacion detallada de un proveedor registrado en el sistama
	public function view($id = null) {
		$this->layout='tabla';
		//se obtiene el id del proveedor que se quiere mostrar su informacion detallada
		$this->Suplier->id=$id;
		
		if (!$this->Suplier->exists()) {
			throw new NotFoundException('El proveedor solicitado no existe');
		}
		//se verifica si existe el id del proveedor solicitado
		if (!$id) {
			$this->Session->setFlash('El id del proveedor solicitado no existe');
			$this->redirect(array('action' => 'index'));
		}
		//Se cargan en la vista los datos del proveedor solicitado en caso de haber sido encontrado
		$this->set('proveedor',$this->Suplier->read());
	}
	//funcion que permite agregar un proveedor
	public function add()
	{	
		$this->layout='tabla';
		//cargamos los datos con las reglas que se van a comparar en el modelo
		$this->Suplier->set($this->request->data);
		
		if ($this->request->is('post')) {
			$this->Suplier->invalidFields(); //se muestran los campos invalidos segun las reglas del modelo
			//consulta equivalente a realizar 		
			//se verifica si ese email ya se encuentra registrado
			if ($this->Suplier->findByEmail($this->data['Suplier']['Email']))
			{
				//se invalida el campo y muestra el mensaje del campo invalido en caso de que ya exista ese email
				$this->Suplier->invalidate('Email','El proveedor con ese email ya se encuentra registrado, escriba otro');
				$this->Session->setFlash('El proveedor no pudo guardarse. verifique que los datos sonm correctos y trata nuevamente.');
			}
			//se valida si ya existe el proveedor con ese nombre y esos apellidos
			if ($this->Suplier->findByNombre_completo($this->data['Suplier']['Nombre_completo']))
			{
				//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese proveedor ya exista
				$this->Suplier->invalidate('Nombre_completo','Ese proveedor ya se encuentra registrado, ingrese otro');
				$this->Session->setFlash('El proveedor no pudo guardarse. verifique que los datos sonm correctos y trata nuevamente.');
			}
			//print_r($proveedores);
			//se valida si el email y el proveedor no se encuentran registrados
    		else if(!$this->Suplier->findByEmail($this->data['Suplier']['Email']) && 
    				!$this->Suplier->findByNombre_completo($this->data['Suplier']['Nombre_completo']))
    		{
    			//se crea un proveedor con los datos que se ingresan
    			$this->Suplier->create();
    			//se capturan y se guardan los datos del proveedor
    			if ($this->Suplier->save($this->request->data))  
    			{
    				//if ($this->RequestHandler->isAjax()) //se verifica si se hace una llamada por ajax
    				//{
    					//$this->set('proveedores',$this->paginate());//cargamos los datos de la lista de proveedores en la vista
    					//$this->render('index','ajax');//se renderiza la vista index con la vista agregar
    				
    				//}
    				//else
    				//{
    					//$this->Session->setFlash("El proveedor fue guardado con exito");
    					//return $this->redirect(array('action'=>'index'));
    				//}
    				
    				$this->Session->setFlash('El Proveedor ha sido guardado con &eacutexito');
    				//se hace una redireccion a index una vez que se guardaron los datos
    				return $this->redirect(array('controller'=>'supliers','action' => 'lista_proveedores'));
    			}
    			else
    			{
    				$this->Session->setFlash('El Proveedor no pudo guardarse.  Revise que los datos son correctos y trata nuevamente');
    			}
    		}
		}
	}
 //Funcion que permite editar proveedores
    public function edit($id = null) 
    {
    	$this->layout='tabla';
    	//se captura el identificador del proveedor a editar
    	$this->Suplier->id = $id;
    	//consulta equivalente a realizar SELECT Email,Nombre_completo FORM supliers WHERE id=$id
    	//obtemos los datos del proveedor actual que se quiere editar y se almacena en un array
    	$proveedorActual=$this->Suplier->find('first',array(
    			//'fields'=>array('Suplier.Email,Suplier.Nombre_completo'),
    			'conditions'=>array(
    					'Suplier.id'=>$this->Suplier->id)
    		)
    	);
    	
    	//print_r($proveedorActual['Producto']);
    	
    	//se verifica si el proveedora editar no existe
    	if (!$this->Suplier->exists())
    	{
    		$this->Session->setFlash('El proveedor a editar no existe.');
    		$this->redirect(array('action' => 'index'));
    	}
    		
    	//cargamos los datos con las reglas que se van a comparar en el modelo
    	$this->Suplier->set($this->request->data); 
    	if ($this->request->is('post') || $this->request->is('put'))  //se realiza una llamada por metodo post
    	{	
    		//se muestran los campos invalidos segun las reglas del modelo
    		$this->Suplier->invalidFields(); 
    		//se valida si ya existe ese Email sin considerar el email del proveedor que se esta editando actualmente
    		if ($this->Suplier->findByEmail($this->data['Suplier']['Email']) && 
    				$this->data['Suplier']['Email']!=$proveedorActual['Suplier']['Email']  )
    		{
    			//se invalida el campo muestra el mensaje del campo invalido en caso de que ya exista ese email
    			$this->Suplier->invalidate('Email','El proveedor con ese email ya se encuentra registrado, escriba otro');
    			$this->Session->setFlash('El proveedor no pudo editarse. Por favor, intenta nuevamente.');
    		}
    		//se valida si ya existe ese proveedor sin considerar el proveedor que se esta editando actualmente
    		if ($this->Suplier->findByNombre_completo($this->data['Suplier']['Nombre_completo']) && 
    				$this->data['Suplier']['Nombre_completo']!=$proveedorActual['Suplier']['Nombre_completo']  )
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese proveedor ya exista
    			$this->Suplier->invalidate('Nombre_completo','Ese proveedor ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El proveedor no pudo editarse. Verifique que los datos son correctos e intente nuevamente.');
    		}
    		//se verifica si el proveedor y el email no se encuentra registrado anteriormente sin considerar los datos del proveedor actual
    		else if ((!$this->Suplier->findByNombre_completo($this->data['Suplier']['Nombre_completo']) || 
    				$this->data['Suplier']['Nombre_completo']==$proveedorActual['Suplier']['Nombre_completo'] )&&
    				(!$this->Suplier->findByEmail($this->data['Suplier']['Email']) || 
    				$this->data['Suplier']['Email']==$proveedorActual['Suplier']['Email']))	
    		{
    			//se capturan y se guardan los datos de ese usuario
    			if ($this->Suplier->save($this->request->data))
    			{
    				$this->Session->setFlash('El proveedor ha sido editado con &eacutexito');
    				$this->redirect(array('controller'=>'supliers','action' => 'lista_proveedores'));
    			} else {
    				$this->Session->setFlash('El proveedor no pudo ser editado. verifique que los datos son correctos y trata nuevamente.');
    			}
    		}
    	}
    	else
    	{
    		// Se capturan los datos del proveedor a editar
    		$this->request->data = $this->Suplier->read(); 
    	}
    }
    /*
	//funcion que permite eliminar un proveedor
	public function delete($id = null) {
		if ($this->request->is('get')){ // se hace una llamada por metodo get
			throw new MethodNotAllowedException();
		}
		if (!$id) { // se verifica si el id del proveedor a eliminar no existe
			$this->Session->setFlash('El Id del proveedor a eliminar no existe');
			$this->redirect(array('action' => 'index'));
		}
		
		
	
		if ($this->Suplier->delete($id)) {
			$this->Suplier->query('ALTER TABLE `suplier` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('El proveedor fue eliminado con exito');
			// se redirecciona a la vista principal donde se encuentra la lista de proveedores
			//s$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash('El proveedor no fue eliminado,  verifica que sea un proveedor valido');
		// se redirecciona a la vista principal donde se encuentra la lista de proveedores
		$this->redirect(array('action' => 'index'));
	}*/
    //Funcion que permite eliminar un elemento
    function delete($id=null) {
    	//Se establece la clase predeterminada y se establece el mensaje para setFlash
    	$class = 'flash_bad';
    	$msg   = 'Id invalido';
    	// Verifica que el id sea valido y que sea numerico
    	if($id!=null && is_numeric($id)) {
    		//Toma un elemento
    		$item = $this->Suplier->read(null,$id);
    		//verifica si el elemento es valido
    		if(!empty($item)) {
    			//Se elimina el elemento
    			if($this->Suplier->delete($id)) {
    				//se reinicia el autoincrement cada que se elimina un elemento
    				$this->Suplier->query('ALTER TABLE `supliers` AUTO_INCREMENT=1 ');
    				$class = 'flash_good';
    				$msg   = 'El Proveedor fue eliminado con exito';
    			} else {
    				$this->Session->setFlash('El Proveedor no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
    			}
    		}
    	}
    	//Salida JSON on AJAX request
    	if($this->RequestHandler->isAjax())
    	{
    		$this->autoRender = $this->layout = false;  //evitar que renderice a otra vista
    		print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
    		exit;
    	}
    	//Se despliega el mensaje y se redirecciona
    	$this->Session->setFlash($msg,'default',array('class'=>$class));
    	$this->redirect(array('controller'=>'supliers','action'=>'lista_proveedores'));
    }
    
	
}
?>
<?php
class DetalleVentasController extends AppController{
	var $name='DetalleVentas';
	var $uses=array('DetalleVenta','Producto');
	
	public function beforeFilter()
	{
		parent::beforeFilter();
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar

		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar
			$this->Auth->allow('index','view','Detalle_venta');
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','add');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' ||  $this->params['action']=='add')
				{
					$this->redirect(array('action'=>'lista_pacientes'));
				}
			}
		}
		else
		{
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}
	}
	//Funcion que muestra los detalle de ventas
	public function index()
	{
		$this->DetalleVenta->query('ALTER TABLE `detalle_ventas` AUTO_INCREMENT=1 ');
		$detalleVentas=$this->DetalleVenta->find('all');
		$this->set('detalleVentas',$detalleVentas);
	}
	public function Detalle_venta($id)
	{
		$this->layout = 'tabla';
		
		
		$detalleVenta=$this->DetalleVenta->find('all',array('conditions'=>array('venta_id'=>$id)));
		$this->set('detalleVenta',$detalleVenta);
		
	
	}
	//Funcion que muestra el detalle de venta
	public function view($id=null)
	{
		$this->layout = 'tabla';
		$this->DetalleVenta->id=$id;
	
		if (!$this->DetalleVenta->exists()) {
			throw new NotFoundException('El Detalle de Venta solicitado no existe');
		}
		if (!$id) {
			$this->Session->setFlash('El id del Detalle de Venta solicitado no existe');
			$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
		}
		$this->set('detalleVenta',$this->DetalleVenta->read());
		//se obtiene la lista de los nombres de los pacientes
		$productos = $this->DetalleVenta->Producto->find('list',array('fields'=>'Producto.Nombre'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('productos',$productos);
	}
	//funcion que genera el detalle de la venta
	public function add()
	{
		if ($this->request->is('post')) {
			$this->DetalleVenta->create();
			if ($this->DetalleVenta->save($this->request->data)) {
				$this->Session->setFlash('El Detalle de Venta fue guardado con exito');
				$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
			} else {
				$this->Session->setFlash('El Detalle de Venta no pudo guardarse, revise que los datos son correctos y trata nuevamente');
			}
		}
	}
	//funcion que permite editar un detalle de venta
	public function edit($id = null) {
		$this->DetalleVenta->id = $id;
	
		if (!$this->DetalleVenta->exists())	{
			throw new NotFoundException('El Detalle de Venta que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->DetalleVenta->save($this->request->data)){
				$this->Session->setFlash('El detalle de venta ha sido editada con exito');
				$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
			} else {
				$this->Session->setFlash('El Detalle de Venta no pudo ser editado, revise que los datos son correctos y trata nuevamente.');
			}
		}
		else {
			$this->request->data = $this->DetalleVenta->read();
		}
	}
	//funcion que permite eliminar un detalle de venta
	public function delete($id = null) {
		if ($this->request->is('get')){
			throw new MethodNotAllowedException();
		}
		if (!$id) {
			$this->Session->setFlash('El id del Detalle de Venta que se desea eliminar no existe');
			$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
		}
		if ($this->DetalleVenta->delete($id)) {
			$this->DetalleVenta->query('ALTER TABLE `detalle_ventas` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('El Detalle de Venta fue eliminado con exito');
			$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
		}
		$this->Session->setFlash('El Detalle de Venta no pudo eliminarse, revise que los datos son correctos y trata nuevamente.');
		$this->redirect(array('controller'=>'DetalleVentas','action' => 'index'));
	}
	
}
?>
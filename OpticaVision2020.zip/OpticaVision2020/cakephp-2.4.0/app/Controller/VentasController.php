<?php
class VentasController extends AppController
{
	var $name='Ventas';
	
	public function beforeFilter()
	{
		parent::beforeFilter();
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar

		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar
			$this->Auth->allow('index','view_reparacion','view_venta','historial_ventas','agregar_venta','agregar_reparacion','escoger_actividad','Detalle_venta');
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','add');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				$this->Auth->allow('add');
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' )
				{
					$this->redirect(array('action'=>'lista_pacientes'));
				}
			}
		}
		else
		{
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}
	}
	//Funcion que muestra todas las ventas realizadas
	public function index()
	{
		$this->Venta->query('ALTER TABLE `ventas` AUTO_INCREMENT=1');
		$ventas=$this->paginate();
		$this->set('ventas',$ventas);	
		if ($this->request->is('post'))
		{
			$buscar =$this->request->data['Venta']['buscar_fecha'];
			if (!empty($buscar))
			{
				$buscar_fecha=$this->Venta->find('all',array('conditions'=>array('Venta.fecha'=>$buscar)));
				if (count($buscar_fecha)>0)
				{
					$this->set('ventas',$buscar_fecha);
					//$this->render('index','tabla');//se renderiza la vista index con la vista agregar
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Venta->invalidate('buscar_fecha','No se encontraron coincidencias con esa fecha');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Venta->invalidate('buscar_fecha','El campo esta vacio, es necesario que escriba algo');
			}
			$this->render('historial_ventas','tabla');
		}
	}
	//Funcion que muestra todas las ventas realizadas
	public function historial_ventas()
	{
		$this->layout='tabla';
		$this->Venta->query('ALTER TABLE `ventas` AUTO_INCREMENT=1');
		$ventas=$this->paginate();
		$this->set('ventas',$ventas);
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['Venta']['buscar_fecha'];
			if (!empty($buscar))
			{
				
				$buscar_fecha=$this->Venta->find('all',array('conditions'=>array('Venta.fecha'=>$buscar)));
				if (count($buscar_fecha)>0)
				{
					$this->set('ventas',$buscar_fecha);
					//$this->render('index','tabla');//se renderiza la vista index con la vista agregar
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Venta->invalidate('buscar_fecha','No se encontraron coincidencias con esa fecha');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Venta->invalidate('buscar_fecha','El campo esta vacio, es necesario que escriba algo');
			}
		}
	}
	/*
	function comprar($idarticulo = null) {
		if ($idarticulo != null) {
			$articulo = $this->Articulo->find('first', array('conditions' => array('Articulo.id' => $idarticulo)));
			if($articulo['Articulo']['stock']>0) {
				[aqu� ir�a la l�gica cuando esta todo ok]
			} else {
				[aqu� ir�a la l�gica para cuando no hay stock]
			}
    }*/
	//Funcion que muestra la informacion detallada de una venta
	public function view_reparacion($id=null)
	{
		$this->layout='tabla';
		$this->Venta->id=$id;
		
		if (!$this->Venta->exists()) {
			throw new NotFoundException('La venta solicitada no existe');
		}
		if (!$id)
		{
			$this->Session->setFlash('El id de la venta solicitada no existe');
			$this->redirect(array('controller'=>'ventas','action' => 'index'));
		}
		$this->set('venta',$this->Venta->read());
		//se capturan la lista de los pacientes registrados
		$pacientes = $this->Venta->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista agregar venta
		$this->set('pacientes',$pacientes);
		
		//se capturan la lista de los usuarios registrados
		$usuarios = $this->Venta->User->find('list',array('fields'=>'User.Nombre_completo'));
		//se pasa la lista capturada de usuarios a la vista agregar venta
		$this->set('usuarios',$usuarios);
	}
	//Funcion que muestra la informacion detallada de una venta
	public function view_venta($id=null)
	{
		$this->layout='tabla';
		$this->Venta->id=$id;
	
		if (!$this->Venta->exists()) {
			throw new NotFoundException('La venta solicitada no existe');
		}
		if (!$id) {
			$this->Session->setFlash('El id de la venta solicitada no existe');
			$this->redirect(array('controller'=>'ventas','action' => 'index'));
		}
		$this->set('venta',$this->Venta->read());
		//se capturan la lista de los pacientes registrados
		$pacientes = $this->Venta->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista agregar venta
		$this->set('pacientes',$pacientes);
	
		//se capturan la lista de los usuarios registrados
		$usuarios = $this->Venta->User->find('list',array('fields'=>'User.Nombre_completo'));
		//se pasa la lista capturada de usuarios a la vista agregar venta
		$this->set('usuarios',$usuarios);
	}
	
	//Funcion que permite agregar una nueva venta
	public function agregar_venta($actividad)
	{
		$this->layout = 'tabla';
		$this->request->data['Venta']['Actividad']=$actividad;
		if ($this->request->is('post')) {
			$this->Venta->create();
		
			if ($this->Venta->save($this->request->data)) {
				$this->Session->setFlash('La venta fue regitrada con &eacutexito');
				$this->redirect(array('controller'=>'ventas','action' => 'historial_ventas'));
			} else {
				$this->Session->setFlash('La venta no pudo registrarse. Verifique que los datos son correctos y trata nuevamente');
			}
		}
		 //se capturan la lista de los pacientes registrados
		$pacientes = $this->Venta->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista agregar venta
		$this->set('pacientes',$pacientes);

		 //se capturan la lista de los usuarios registrados
		$usuarios = $this->Venta->User->find('list',array('fields'=>'User.Nombre_completo'));
		//se pasa la lista capturada de usuarios a la vista agregar venta
		$this->set('usuarios',$usuarios);
	}
	//Funcion que permite agregar una nueva venta
	public function agregar_reparacion($actividad)
	{
		//$tipo_paggo = 'pago completo';
		$this->layout = 'tabla';
		
		$this->request->data['Venta']['Actividad']= $actividad;
		$this->request->data['Venta']['Liquidado'] = 1;
		$this->request->data['Venta']['Tipo_pago'] = 'pago completo';
		if ($this->request->is('post')) {
			$this->Venta->create();
			if ($this->Venta->save($this->request->data)) {
				$this->Session->setFlash('La venta fue registrada con &eacutexito');
				$this->redirect(array('controller'=>'ventas','action' => 'historial_ventas'));
			} else {
				$this->Session->setFlash('La venta no pudo registrarse. Verifique que los datos son correctos y trata nuevamente');
			}
			
		}
		//se capturan la lista de los pacientes registrados
		$pacientes = $this->Venta->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista agregar venta
		$this->set('pacientes',$pacientes);
	
		//se capturan la lista de los usuarios registrados
		$usuarios = $this->Venta->User->find('list',array('fields'=>'User.Nombre_completo'));
		//se pasa la lista capturada de usuarios a la vista agregar venta
		$this->set('usuarios',$usuarios);
	}
	public function escoger_actividad()
	{
		$this->layout='tabla';
		if ($this->request->is('post'))
		{
			if ($this->request->data['Venta']['Actividad']=='Reparacion')
			{
				$this->redirect(array('controller'=>'ventas','action'=>'agregar_reparacion',$this->data['Venta']['Actividad']));
			}
			else if ($this->request->data['Venta']['Actividad']=='Venta')
			{
				$this->redirect(array('controller'=>'ventas','action'=>'agregar_venta',$this->data['Venta']['Actividad']));
			}
			else
			{
				$this->Session->setFlash('Es necesario que seleccione una actividad');
			}
		}
	}
	//Funcion que permite editar una venta
	public function edit($id)
	{
		$this->Venta->id = $id;
		
		if (!$this->Venta->exists())	{
			throw new NotFoundException('La venta que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->Anticipo->save($this->request->data)){
				$this->Session->setFlash('El anticipo ha sido editada con exito');
				$this->redirect(array('controller'=>'anticipos','action' => 'historial_ventas'));
			} else {
				$this->Session->setFlash('El anticipo no pudo ser editado, revise que los datos son correctos y trata nuevamente.');
			}
		}
		else {
			$this->request->data = $this->Anticipo->read();
		}
	}
	
}
?>
<?php
class ProductosController extends AppController
{
	var $name='Productos';
	var $uses=array('Producto','Material','Accesorio');//Se cargan los modelos que se necesitaran
	//var $helpers = array('Js','Html', 'Form');
	var $components = array( 'RequestHandler' ); // variable que sirve para poder hacer request por medio de ajax

	public function beforeFilter()
	{
		parent::beforeFilter();
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar

		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar
			$this->Auth->allow('index','view_material','view_accesorio','view_armazon','view_lente_contacto','lista_productos'
					,'agregar_accesorio','agregar_armazon','agregar_lente_contacto'
						,'agregar_material','agregar_productos');
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('editar_accesorio',
						'editar_armazon','editar_lente_contacto','editar_material','delete','table');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'editar_accesorio' ||  
						$this->params['action']=='editar_armazon' || $this->params['action']=='editar_lente_contacto' ||
						$this->params['action']=='editar_material')
				{
					$this->Session->setFlash('No estas autorizado para realizar esta accion');
					$this->redirect(array('action'=>'lista_productos'));
				}
			}
		}
		else
		{
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}
	}
	public function index()
	{

		$this->Producto->query('ALTER TABLE `productos` AUTO_INCREMENT=1 ');
		$this->Producto->recursive = 0;
		$productos=$this->paginate();
		$this->set('productos',$productos);
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['Producto']['buscar'];
			if (!empty($buscar))
			{
				$buscar=$this->Producto->find('all',array('conditions'=>array(
						'OR'=>array('Producto.Nombre'=>$buscar,'Producto.Descripcion'=>$buscar,
								'Producto.Tipo_producto'=>$buscar,'Producto.Marca'=>$buscar,
								'Producto.Caracteristica'=>$buscar,'Producto.Genero'=>$buscar,
								'Suplier.Nombre_completo LIKE'=>'%'.$buscar.'%'))
					)
				);
			
				if (count($buscar)>0)
				{
					$this->set('productos',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Producto->invalidate('buscar','No se encontraron coincidencias de ese producto');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Producto->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}
			$this->render('lista_productos','tabla');//se renderiza la vista index a otra vista
		}
		
	
		
	}
	public function Lista_productos()
	{
		$this->layout='tabla';
		$this->Producto->query('ALTER TABLE `productos` AUTO_INCREMENT=1 ');
		$this->Producto->recursive = 0;
		$productos=$this->paginate();
		//$this->set('Productos', $this->paginate());
		$this->set('productos',$productos);
		//$materiales=$this->Material->find('all');
		//print_r($materiales);
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['Producto']['buscar'];
			if (!empty($buscar))
			{
				$buscar=$this->Producto->find('all',array('conditions'=>array(
						'OR'=>array('Producto.Nombre'=>$buscar,'Producto.Descripcion'=>$buscar,
								'Producto.Tipo_producto'=>$buscar,'Producto.Marca'=>$buscar,
								'Producto.Caracteristica'=>$buscar,'Producto.Genero'=>$buscar,
								'Suplier.Nombre_completo LIKE'=>'%'.$buscar.'%'
								))
					)
				);
			
				if (count($buscar)>0)
				{
					$this->set('productos',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Producto->invalidate('buscar','No se encontraron coincidencias de ese producto');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Producto->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}
		}
		
	}
	//Funcion que muestra la informacion detallada de un producto registrado en el sistema
	public function view_material($id = null) {	
		$this->layout='tabla';
		//se obtiene el id del producto que se quiere mostrar su informacion detallada
		$this->Producto->id=$id;
		//se verifica si el producto que se desea ver existe
		if (!$this->Producto->exists()) {
			throw new NotFoundException('El producto solicitado no existe, favor de verificar que los datos sean correctos');
		}
		//se verifica si existe el id del producto solicitado
		if (!$id) {
			$this->Session->setFlash('El id del producto solicitado no existe, favor de verificar que el id del producto sea correcto');
			$this->redirect(array('action' => 'index'));
		}
		
		//Se cargan en la vista los datos del producto solicitado en caso de haber sido encontrado
		$this->set('producto',$this->Producto->read());
		//se obtiene la lista de los nombres de los proveedores
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('proveedores',$proveedores);
	}
	//Funcion que muestra la informacion detallada de un producto registrado en el sistema
	public function view_armazon($id=null)
	{
		$this->layout='tabla';
		//se obtiene el id del producto que se quiere mostrar su informacion detallada
		$this->Producto->id=$id;
		//se verifica si el producto que se desea ver existe
		if (!$this->Producto->exists())
		{
			throw new NotFoundException("El producto solicitado no existe,  favor de verificar que los datos sean correctos");
		}
		//se verifica si existe el id del producto solicitado
		if (!$id)
		{
			$this->Session->setFlash('El id del producto solicitado no existe,  favor de verificar que el id del producto sea correcto');
			$this->redirect(array('action'=>'index'));
		}
		//Se cargan en la vista los datos del producto solicitado en caso de haber sido encontrado
		$this->set('producto',$this->Producto->read());
		//se obtiene la lista de los nombres de los proveedores
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('proveedores',$proveedores);
	
	
	}
	//Funcion que muestra la informacion detallada de un producto registrado en el sistema
	public function view_accesorio($id=null)
	{
		$this->layout='tabla';
		//se obtiene el id del producto que se quiere mostrar su informacion detallada
		$this->Producto->id=$id;
		//se verifica si el producto que se desea ver existe
		if (!$this->Producto->exists())
		{
			throw new NotFoundException("El producto solicitado no existe, favor de verificar que los datos sean correctos");
		
		}
		//se verifica si existe el id del producto solicitado
		if (!$id)
		{
			$this->Session->setFlash('El id del producto solicitado no existe, favor de verificar que el id del producto sea correcto');
			$this->redirect(array('action'=>'index'));
		}
		//Se cargan en la vista los datos del producto solicitado en caso de haber sido encontrado
		$this->set('producto',$this->Producto->read());
		//se obtiene la lista de los nombres de los proveedores
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('proveedores',$proveedores);
		
	}
	//Funcion que muestra la informacion detallada de un producto registrado en el sistema
	public function view_lente_contacto($id=null)
	{
		$this->layout='tabla';
		//se obtiene el id del producto que se quiere mostrar su informacion detallada
		$this->Producto->id=$id;
		//se verifica si el producto que se desea ver existe
		if (!$this->Producto->exists())
		{
			throw new NotFoundException("El producto solicitado no existe, favor de verificar que los datos sean correctos");
				
		}
		//se verifica si existe el id del producto solicitado
		if (!$id)
		{
			$this->Session->setFlash('El id del producto solicitado no existe, favor de verificar que el id del producto sea correcto');
			$this->redirect(array('action'=>'index'));
		}
		//Se cargan en la vista los datos del producto solicitado en caso de haber sido encontrado
		$this->set('producto',$this->Producto->read());
		//se obtiene la lista de los nombres de los proveedores
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('proveedores',$proveedores);
	}
	
	//Funcion que permite agregar un producto
	public function agregar_material($producto)
	{
		$this->layout='tabla';
		
		//Se obtiene el listado de los materiales disponibles
		$listado_materiales=$this->Material->find('list',array(
				'fields'=>array('Material.Material')));
		//pasamos el listado de los materiales a la vista agregar
		$this->set('listado_materiales',$listado_materiales);
		//se asigna el tipo de producto
		$this->request->data['Producto']['Tipo_producto']=$producto;
	
	
		
		//print_r($producto);
		if ($this->request->is('post'))
		{		
			
			//Se almacena el nombre del material
			$this->request->data['Producto']['Nombre']=$listado_materiales[$this->data['Producto']['Nombre']];
			//print_r($this->data['Producto']['Nombre']);	
			$this->Producto->create();
			if ($this->Producto->save($this->request->data))
			{
				
				$this->Session->setFlash('El Producto ha sido guardado con &eacutexito');
				return $this->redirect(array('controller'=>'productos','action'=>'Lista_productos'));
			}
			else
			{
				$this->Session->setFlash("El producto no pudo guardar, verifica que los datos sean correctos");
			}
			
		}
		//se obtiene la lista de los nombres de los proveedores
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('proveedores',$proveedores);
		
	}
	
	public function agregar_accesorio($producto)
	{
		$this->layout='tabla';
		$listado_accesorios=$this->Accesorio->find('list',array(
				'fields'=>array('Accesorio.Nombre')));		
		//pasamos el listado de los accesorios a la vista agregar
		$this->set('listado_accesorios',$listado_accesorios);
		//se asigna el tipo de producto
		$this->request->data['Producto']['Tipo_producto']=$producto;
		if ($this->request->is('post'))
		{
			//Se almacena la caracteristica del accesorio
			$this->request->data['Producto']['Caracteristica']=$listado_accesorios[$this->data['Producto']['Caracteristica']];
			//se crea el producto
			$this->Producto->create();
			//se guarda el producto
			if ($this->Producto->save($this->request->data))
			{
				$this->Session->setFlash('El Producto ha sido guardado con &eacutexito');
				return $this->redirect(array('controller'=>'productos','action'=>'Lista_productos'));
			}
			else
			{
				$this->Session->setFlash("El producto no pudo guardar, verifica que los datos sean correctos");
			}
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
		
		
	}
	public function agregar_lente_contacto($producto)
	{
		$this->layout='tabla';
		//se asigna el tipo de producto
		$this->request->data['Producto']['Tipo_producto']=$producto;
		if ($this->request->is('post'))
		{
			$this->Producto->create();
			if ($this->Producto->save($this->request->data))
			{
				$this->Session->setFlash('El Producto ha sido guardado con &eacutexito');
				return $this->redirect(array('controller'=>'productos','action'=>'Lista_productos'));
			}
			else
			{
				$this->Session->setFlash("El producto no pudo guardar, verifica que los datos sean correctos");
			}
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	public function agregar_armazon($producto)
	{
		$this->layout='tabla';
		//se asigna el tipo de producto
		$this->request->data['Producto']['Tipo_producto']=$producto;
		if ($this->request->is('post'))
		{
			$this->Producto->create();
			if ($this->Producto->save($this->request->data))
			{
				$this->Session->setFlash('El Producto ha sido guardado con &eacutexito');
				return $this->redirect(array('controller'=>'productos','action'=>'Lista_productos'));
			}
			else
			{
				$this->Session->setFlash("El producto no pudo guardar, verifica que los datos sean correctos");
			}
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	public function agregar_productos()
	{
		$this->layout='tabla';
		//if (isset($this->request->data['submit']))
		if ($this->request->is('post')) //capturar evento de un boton submit
		{
			if ($this->request->data['Producto']['Tipo_producto']=='Material')
			{
				$this->redirect(array('action'=>'agregar_material',$this->data['Producto']['Tipo_producto']));

			}
			else if ($this->request->data['Producto']['Tipo_producto']=='Armazon')
			{
				return $this->redirect(array('action'=>'agregar_armazon',$this->data['Producto']['Tipo_producto']));

			}
			else if ($this->request->data['Producto']['Tipo_producto']=='Accesorio')
			{
				return $this->redirect(array('action'=>'agregar_accesorio',$this->data['Producto']['Tipo_producto']));

			}
			else if ($this->request->data['Producto']['Tipo_producto']=='Lentes de contacto')
			{
				return $this->redirect(array('action'=>'agregar_lente_contacto',$this->data['Producto']['Tipo_producto']));

			}
			else
			{
				$this->Session->setFlash("Se necesita que seleccione el producto que desea agregar");
			}

		}
	}
	//funcion que permite editar un producto
	public function editar_material($id = null) {
		$this->layout = 'tabla';
		//se captura el identificador del producto a editar
		$this->Producto->id = $id;
		//Se obtiene el listado de los materiales disponibles
		$listado_materiales=$this->Material->find('list',array(
				'fields'=>array('Material.Material')));
		//pasamos el listado de los materiales a la vista agregar
		$this->set('listado_materiales',$listado_materiales);
		//se verifica si el producto a editar no existe
		if (!$this->Producto->exists())	{
			throw new NotFoundException('El producto a editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			//Se almacena el nombre del material
			$this->request->data['Producto']['Nombre']=$listado_materiales[$this->data['Producto']['Nombre']];
			//se capturan y se guardan los datos de ese paciente
			if ($this->Producto->save($this->request->data)){
				$this->Session->setFlash('El producto ha sido editado con &eacutexito');
				$this->redirect(array('controller'=>'productos','action' => 'Lista_productos'));
			} else {
				$this->Session->setFlash('El producto no pudo ser editado. Verifique que los datos sean correctos.');
			}
	
		} else {
			// Se capturan los datos del paciente a editar
			$this->request->data = $this->Producto->read();
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	//funcion que permite editar un producto
	public function editar_armazon($id = null) {
		$this->layout = 'tabla';
		//se captura el identificador del producto a editar
		$this->Producto->id = $id;
		//se verifica si el producto a editar no existe
		if (!$this->Producto->exists())	{
			throw new NotFoundException('El producto a editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			
			//se capturan y se guardan los datos de ese paciente
			if ($this->Producto->save($this->request->data)){
				$this->Session->setFlash('El producto ha sido editado con &eacutexito');
				$this->redirect(array('controller'=>'productos','action' => 'Lista_productos'));
			} else {
				$this->Session->setFlash('El producto no pudo ser editado. Verifique que los datos sean correctos.');
			}
	
		} else {
			// Se capturan los datos del paciente a editar
			$this->request->data = $this->Producto->read();
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	//funcion que permite editar un producto
	public function editar_accesorio($id = null) {
		$this->layout = 'tabla';
		//se captura el identificador del producto a editar
		$this->Producto->id = $id;
		//cargamos el modelo accesorio
		//$this->loadModel('Accesorio');
		//Se obtiene el listado de los materiales disponibles
		$listado_accesorios=$this->Accesorio->find('list',array('fields'=>array('Accesorio.Nombre')));	
		//pasamos el listado de los materiales a la vista agregar
		$this->set('listado_accesorios',$listado_accesorios);
		//se verifica si el producto a editar no existe
		if (!$this->Producto->exists())	{
			throw new NotFoundException('El producto a editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			//Se almacena la caracteristica del accesorio
			$this->request->data['Producto']['Caracteristica']=$listado_accesorios[$this->data['Producto']['Caracteristica']];
			//se capturan y se guardan los datos de ese producto
			if ($this->Producto->save($this->request->data)){
				$this->Session->setFlash('El producto ha sido editado con &eacutexito');
				$this->redirect(array('controller'=>'productos','action' => 'Lista_productos'));
			} else {
				$this->Session->setFlash('El producto no pudo ser editado. Verifique que los datos sean correctos.');
			}
	
		} else {
			// Se capturan los datos del paciente a editar
			$this->request->data = $this->Producto->read();
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	//funcion que permite editar un producto
	public function editar_lente_contacto($id = null) {
		$this->layout = 'tabla';
		//se captura el identificador del producto a editar
		$this->Producto->id = $id;
		//se verifica si el producto a editar no existe
		if (!$this->Producto->exists())	{
			throw new NotFoundException('El producto a editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			//se capturan y se guardan los datos de ese paciente
			if ($this->Producto->save($this->request->data)){
				$this->Session->setFlash('El producto ha sido editado con &eacutexito');
				$this->redirect(array('controller'=>'productos','action' => 'Lista_productos'));
			} else {
				$this->Session->setFlash('El producto no pudo ser editado. Verifique que los datos sean correctos.');
			}
		
	
		} else {
			// Se capturan los datos del paciente a editar
			$this->request->data = $this->Producto->read();
		}
		//se capturan los proveedores registrados
		$proveedores = $this->Producto->Suplier->find('list',array('fields'=>'Suplier.Nombre_completo'));
		//se pasa la lista capturada de proveedores a la vista agregar
		$this->set('proveedores',$proveedores);
	}
	
	//Funcion que permite eliminar un elemento
	function delete($id=null) {
		//Se establece la clase predeterminada y se establece el mensaje para setFlash
		$class = 'flash_bad';
		$msg   = 'Invalid List Id';
		// Verifica que el id sea valido y que sea numerico
		if($id!=null && is_numeric($id)) {
			//Toma un elemento
			$item = $this->Producto->read(null,$id);
			//verifica si el elemento es valido
			if(!empty($item)) {
				//Se elimina el elemento
				if($this->Producto->delete($id)) {
					//se reinicia el autoincrement cada que se elimina un elemento
					$this->Producto->query('ALTER TABLE `productos` AUTO_INCREMENT=1 ');
					$class = 'flash_good';
					$msg   = 'El Producto fue elimina con exito';
				} else {
					$this->Session->setFlash('El Producto no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
				}
			}
		}
		//Salida JSON on AJAX request
		if($this->RequestHandler->isAjax())
		{
			$this->autoRender = $this->layout = false;
			print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
			exit;
		}
		//Se despliega el mensaje y se redirecciona
		$this->Session->setFlash($msg,'default',array('class'=>$class));
		$this->redirect(array('controller'=>'productos','action'=>'Lista_productos'));
	}
	
}
?>
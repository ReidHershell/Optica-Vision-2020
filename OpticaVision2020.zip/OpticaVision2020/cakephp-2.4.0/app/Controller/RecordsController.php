<?php
class RecordsController extends AppController
{
	var $name = 'Records';
	//var $helpers = array('Js','Html', 'Form');
	var $components = array( 'RequestHandler' ); // variable que permite poder hacer request por medio de ajax
	
	public function beforeFilter() 
	{	
		parent::beforeFilter();	
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar
		
		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{		
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar		
			$this->Auth->allow('index','view','lista_pacientes','historial','add');		
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar historiales
				$this->Auth->allow('edit','delete','table');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{	
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit')
				{
					$this->Session->setFlash('No estas autorizado para realizar esta accion');
					$this->redirect(array('controller'=>'pacientes','action'=>'lista_pacientes'));
				}			
			}
		}
		else
		{	
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}		
	}
	//Funcion que muestra los historiales de los pacientes
	public function index() {
		$this->layout = 'tabla';
		$this->Record->query('ALTER TABLE `historiales` AUTO_INCREMENT=1 ');
		$this->Record->recursive = 0;

		$historiales=$this->paginate();
		$this->set('historiales', $historiales);
		/*
		if ($this->request->is('post'))
		{

			$nombre=$this->request->data['Record']['buscar_nombre'];
			$fecha=$this->request->data['Record']['buscar_fecha'];
			if (empty($nombre) && empty($fecha))
			{
				//se invalida el campo en caso de que este vacio
				$this->Record->invalidate('buscar_nombre','El campo nombre esta vacio, Es necesario que escriba algo');
				$this->Record->invalidate('buscar_fecha','El campo fecha esta vacio, Es necesario que escriba algo');
			}
			else if (!empty($nombre) && !empty($fecha))
			{
				$buscar_nombre_fecha=$this->Record->Paciente->find('all',array(
						'conditions'=>array(
								'AND' =>array('Paciente.Nombre_completo LIKE'=>'%'.$nombre.'%','Record.Fecha_registro'=>$fecha)
						)
				));
				if (count($buscar_nombre_fecha)>0)
				{
					//se pasa la a la vista la lista con todas las coincidencias que se hayan tenido con esa fecha y ese nombre
					$this->set('historiales',$buscar_nombre_fecha);
				}
				else
				{
					//se invalidan los campos de nombre y fecha en caso no que no haya existido ninguna coincidencia con el nombre y la fecha
					$this->Record->invalidate('buscar_nombre','No se encontraron coincidencias con ese nombre y esa fecha');
					$this->Record->invalidate('buscar_fecha','No se encontraron coincidencias con esa fecha y ese nombre');
				}
			}
			else if (!empty($nombre) || !empty($fecha))
			{
				//$buscar = $this->Record->findAll($this->postConditions($this->request->data['Record']['buscar']));
				$buscar_nombre=$this->Record->Paciente->find('all',array('conditions'=>array('Paciente.Nombre_completo LIKE'=>'%'.$nombre.'%')));
				$buscar_fecha=$this->Record->find('all',array('conditions'=>array('Record.Fecha_registro '=>$fecha)));
				if (count($buscar_nombre)>0)
				{
					//se pasa la a la vista la lista con todas las coincidencias que se hayan tenido con ese nombre
					$this->set('historiales',$buscar_nombre);		
				}
				if (count($buscar_fecha)>0)
				{
					//se pasa la a la vista la lista con todas las coincidencias que se hayan tenido con esa fecha
					$this->set('historiales',$buscar_fecha);	
				}
				if (count($buscar_fecha)<=0 && empty($nombre))
				{
					//se invalida el campo en caso de que este vacio
					$this->Record->invalidate('buscar_fecha','No se encontraron coincidencias con esa fecha');
				
				}
				if (count($buscar_nombre)<=0 && empty($fecha))
				{
					//se invalida el campo en caso de que este vacio
					$this->Record->invalidate('buscar_nombre','No se encontraron coincidencias con ese nombre');
				}
			}
		}*/
	}
	public function historial($id)
	{
		$this->layout = 'tabla';
		
		//$this->Record->paciente_id=$id;
		//print_r($this->Record->paciente_id);
		//print_r("id ".$this->Record->paciente_id);
		//print_r("id ".$this->data['Record']['Fecha_registro']);
		//se capturan los pacientes registrados
		//obtemos los datos del usuario actual que se quiere editar y se almacena en un array
		/*
		$usuarioActual=$this->User->find('first',array(
				'fields'=>array('User.Email,User.username,User.Rfc,User.Palabra_secreta,User.Nombre_completo'),
				'conditions'=>array(
						'User.id'=>$this->User->id)));
		$pacientes = $this->Record->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo')*/
		$pacienteEncontrado=$this->Record->find('count',array('fields'=>'paciente_id','conditions'=>array('paciente_id'=>$id)));
		//print_r($pacienteEncontrado);
		if ($pacienteEncontrado)
		{
			//$this->Record->paciente_id=$id;
			$historial=$this->Record->find('all',array('conditions'=>array('paciente_id'=>$id)));
			$this->set('historiales',$historial);
		}
		else
		{
			$this->redirect(array('controller'=>'Records','action' => 'add',$id));
		}
		//$paciente=$this->Record->find('all');
		/*foreach ($paciente as $pacienteActual)
		print_r($pacienteActual);
		
		if (isset($pacienteActual))
		{
			print_r("Arreglo con valores");
		}
		else
		{
			print_r("Arreglo vacio");
		}*/
		/*
		if ($pacienteActual['Record']['paciente_id']==$id)
		{
			
			print("correcto");
		}	*/
		/*
		if (!$this->Record->exists()) {
			throw new NotFoundException('El historial solicitado no existe');
		}*/
		/*
		//se verifica si existe el id del paciente solicitado
		if ($id!=$this->data['Record']['paciente_id']) {
			$this->Session->setFlash('El id del historial solicitado no existe');
			//$this->redirect(array('controller'=>'Records','action' => 'add'));
		}
		else
		{
			print_r('probando funcion'); 
			print_r('id '.$id);
			$historialEncontado=$this->Record->find('all');
			$this->set('historiales',$historialEncontado);
		}*/
		
		/*
		$this->Paciente->Record->read(null, 1);
		//$this->request->data['Record']['Necesidad_visual']='aaaa';
		$this->Paciente->Record->set(array('Necesidad_visual'=>'Ninguna','Lugar_ult_ex'=>'Morelia'));//actualizar registros de una base de datos
		$this->Paciente->Record->save();*/
	
		/*
		$output = $this->requestAction(
				array('controller' => 'records', 'action' => 'prueba',1,2)//llamar a una funcion de otro controlador
		);*/

		//$this->requestAction('/records/index');
		//$this->set('historiales',$output);
		//print_r("salida ".$output);	
		/*
		$params = array('equipo_id'=>$equipo_id, 'numero_equipo'=>$numero, 'obra_id'=>$obra_id, 'fecha >'=>$fecha_ini, 'fecha <'=>$fecha_fin);
		$datos = $this->field('SUM(total)', $params  );
		return $datos;*/ //Sumar campos en cakephp	
	}
	//Funcion que muestra el historial de un paciente en particular
	public function view($id = null) {
		$this->layout = 'tabla';
		$this->Record->id=$id;
	
		if (!$this->Record->exists()) {
			throw new NotFoundException('El historial solicitado no existe');
		}
		if (!$id) {
			$this->Session->setFlash('El id del historial solicitado no existe');
			$this->redirect(array('action' => 'index'));
		}
		$this->set('record',$this->Record->read());
		//se obtiene la lista de los nombres de los pacientes
		$pacientes = $this->Record->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('pacientes',$pacientes);
	}
	//funcion que agrega un historial
	public function add($paciente)
	{

		$this->layout = 'tabla';
		//se asigna el paciente
		$this->request->data['Record']['paciente_id']=$paciente;
		
		if ($this->request->is('post')) {
		
			if(!$this->Record->findBypaciente_id($this->data['Record']['paciente_id']))
			{
				$this->Record->create();
				if ($this->Record->save($this->request->data)) {
					$this->Session->setFlash('El historial fue guardado con &eacutexito');
					$this->redirect(array('controller'=>'records','action'=>'historial',$this->data['Record']['paciente_id']));
				} else {
					$this->Session->setFlash('El historial no pudo guardarse, revise que los datos son correctos y trata nuevamente');
				}
			}
			else
			{
				//$this->render('Lista_pacientes','tabla');
				$this->redirect(array('controller'=>'records','action'=>'historial',$this->data['Record']['paciente_id']));
			}
		}
		/*
		 //se capturan los pacientes registrados
		$pacientes = $this->Record->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo',array('conditions'=>array('paciente_id'=>$paciente))));

		//se pasa la lista capturada de pacientes a la vista agregar
		$this->set('pacientes',$pacientes);*/
	}
	public function table($id = null) {
		$this->layout = false;
		$this->Record->id=$id;
		if (!$this->Record->exists()) {
			throw new NotFoundException('El historial solicitado no existe');
		}
		if (!$id) {
	
			$this->Session->setFlash('El id del historial solicitado no existe');
	
			$this->redirect(array('action' => 'hitorial'));
		}
		$this->set('record',$this->Record->read());
		//se obtiene la lista de los nombres de los pacientes
		$pacientes = $this->Record->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se cargan los nombres de los proveedores en la vista
		$this->set('pacientes',$pacientes);
	}

	//funcion que edita un historial
	public function edit($id = null) {
		$this->layout = 'tabla';
		$this->Record->id = $id;
	
		if (!$this->Record->exists())	{
			throw new NotFoundException('El historial que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			
			if ($this->Record->save($this->request->data)){
				$this->Session->setFlash('El historial ha sido editado con &eacutexito');
				$this->redirect(array('controller'=>'records','action'=>'historial',$this->data['Record']['paciente_id']));
			} else {
				$this->Session->setFlash('El historial no pudo ser guardado, revise que los datos son correctos y trata nuevamente');
			}
		} else {
			$this->request->data = $this->Record->read();
			$this->set('record',$this->Record->read());
		}
		
		//se capturan los pacientes registrados
		$pacientes = $this->Record->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista editar
		$this->set('pacientes',$pacientes);
	
	}
	/*
	//funcion que permite eliminar un historial
	public function delete($id = null) {
		if ($this->request->is('get')){
			throw new MethodNotAllowedException();
		}
		if (!$id) {
			$this->Session->setFlash('El id del historial que se desea eliminar no existe');
			$this->redirect(array('controller'=>'records','action' => 'index'));
		}
		
		
		//se captura el id del proveedor a eliminar y posteriormente una vez encontrado su id este se elimina
		if ($this->Record->delete($id)) {
			$this->Record->query('ALTER TABLE `historiales` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('El historial fue eliminado con exito');
			$this->redirect(array('controller'=>'records','action' => 'index'));
			
		}
		$this->Session->setFlash('El historial no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
		$this->redirect(array('controller'=>'records','action' => 'index'));
	}
	*/
	//Funcion que permite eliminar un elemento
	function delete($id=null) {
		//Se establece la clase predeterminada y se establece el mensaje para setFlash
		$class = 'flash_bad';
		$msg   = 'Invalid List Id';	
		// Verifica que el id sea valido y que sea numerico
		if($id!=null && is_numeric($id)) {
			//Toma un elemento
			$item = $this->Record->read(null,$id);	
			//verifica si el elemento es valido
			if(!empty($item)) {
			//Se elimina el elemento
				if($this->Record->delete($id)) {
					//se reinicia el autoincrement cada que se elimina un elemento
					$this->Record->query('ALTER TABLE `historiales` AUTO_INCREMENT=1 ');
					$class = 'flash_good';			
					$msg   = 'El Historial fue eliminado con exito';
				} else {
					$this->Session->setFlash('El Historial no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
				}
			}
		}
		//Salida JSON on AJAX request
		if($this->RequestHandler->isAjax())
		{
			$this->autoRender = $this->layout = false;
			print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
			exit;
		}
		//Se despliega el mensaje y se redirecciona
		$this->Session->setFlash($msg,'default',array('class'=>$class));
		$this->redirect(array('controller'=>'records','action'=>'index'));
	}
}
?>
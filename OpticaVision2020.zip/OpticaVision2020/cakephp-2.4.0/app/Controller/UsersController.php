<?php
class UsersController extends AppController{
	var $name='Users';
	var $components = array( 'RequestHandler' ); // variable que sirve para poder hacer request por medio de ajax
	//var $helpers = array('Js','Html', 'Form');
	//var $helpers = array ('Session');
	//var $components = array ('Auth','Session');
	
	//funcion que filtra las acciones que los usuarios podran realizar
	public function beforeFilter()
	{

		parent::beforeFilter();
		//$this->Auth->allowedActions=array('login','change_password','email','logout');



		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
				
			$this->Auth->allow('index','view','lista_usuarios');
			//$this->Auth->allow('Controllers/Users/index', 'Controllers/Users/view','Controllers/Users/lista_usuarios');

			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','add','table');
				//$this->Auth->allowedActions=array('edit','delete','add');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				//$this->Auth->deny('delete','edit','add');
				// Ahora, nos aseguramos de cerrar la sesi�n en caso que se deniegue el acceso v�a Auth+Acl.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' ||  $this->params['action']=='add')
				{
					$this->Session->setFlash('No puedes realizar esta operacion, se requiere que seas administrador.');
						
					$this->redirect(array('controller'=>'users','action'=>'lista_usuarios'));
						
				}

			}
				
				
			//$this->redirect(array('controller'=>'users','action' =>  'index'));
		}
		else
		{

			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
			//$this->Session->setFlash('');
		}
	}
	
	public function table() {
	
		$this -> layout = false;
		//se reinicia el contador de auto incremento cada que se muestra la vista index
		$this -> User -> query('ALTER TABLE `users` AUTO_INCREMENT=1 ');
	
		$this -> set('users', $this -> paginate());
	}
	//funcion que muestra la lista de los usuarios que se encuentran registrados
	public function index()
	{
		//se reinicia el contador de auto incremento cada que se muestra la vista index
		$this->User->query('ALTER TABLE `users` AUTO_INCREMENT=1 ');

		$this->User->recursive = 0;
		$usuarios=$this->paginate();
		//se cargan todos los datos almacenados
		$this->set('usuarios', $usuarios);

		if ($this->request->is('post'))
		{

			$buscar=$this->request->data['User']['buscar'];
			if (!empty($buscar))
			{
				$buscar=$this->User->find('all',array('conditions'=>array(
						'OR'=>array('User.Nombre_completo LIKE'=>'%'.$buscar.'%','User.Email'=>$buscar,'User.username'=>$buscar))
				)
				);
				if (count($buscar)>0)
				{
					$this->set('usuarios',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->User->invalidate('buscar','No se encontraron coincidencias de ese Usuario');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->User->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}
				
			$this->render('lista_usuarios','tabla');//se renderiza la vista index a otra vista
		}

	}
	//funcion que muestra la lista de usuarios
	public function lista_usuarios() {
		$this->layout='tabla';
		//se reinicia el contador de auto incremento cada que se muestra la vista index
		$this->User->query('ALTER TABLE `users` AUTO_INCREMENT=1 ');


		$this->User->recursive = 0;
		$usuarios=$this->paginate();
		//se cargan todos los datos almacenados
		$this->set('usuarios', $usuarios);
			
		if ($this->request->is('post'))
		{
			$buscar=$this->request->data['User']['buscar'];
			if (!empty($buscar))
			{
				$buscar=$this->User->find('all',array('conditions'=>array(
						'OR'=>array('User.Nombre_completo LIKE'=>'%'.$buscar.'%','User.Email'=>$buscar,'User.username'=>$buscar))
				)
				);

				if (count($buscar)>0)
				{
					$this->set('usuarios',$buscar);
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->User->invalidate('buscar','No se encontraron coincidencias de ese Usuario');
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->User->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
			}

				
		}

	}
	//Funcion que muestra el detallle de un usuario que se encuentra registrado en el sistema
	public function view($id = null) 
	{
		$this->layout='tabla';
        $this->User->id = $id;
        //se verifica si el usuario no existe
        if (!$this->User->exists())
        {
            throw new NotFoundException('El Usuario a mostrar no existe');
        }
        //se verifica si existe el id del proveedor solicitado
        if (!$id) {
        	$this->Session->setFlash('El id del usuario solicitado no existe');
        	$this->redirect(array('controller'=>'usersa','action' => 'index'));
        }
        //si existe el usuario se cargan sus datos
        $this->set('usuario', $this->User->read(null, $id));
    }

    //Funcion que permite agregar usuarios
    public function add() 
    {	
    	$this->layout='tabla';
    	//cargamos los datos con las reglas que se van a comparar en el modelo
    	$this->User->set($this->request->data); 
    	//se realiza una llamada por metodo post
    	if ($this->request->is('post'))  
    	{
    		//se muestran los campos invalidos segun las reglas del modelo
    		$this->User->invalidFields(); 
    		//se verifica si ese usuario ya se encuentra registrado
    		if ($this->User->findByusername($this->data['User']['username'])) 
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese username ya exista
    			$this->User->invalidate('username','Ese Usuario ya se encuentra registrado, ingrese otro'); 
    			$this->Session->setFlash('El usuario no pudo guardarse. Verifique que lod datos son correctos e intente nuevamente.');
    		}
    		//se verifica si el usuario con ese nombre ya se encuentra registrado
    		if ($this->User->findByNombre_completo($this->data['User']['Nombre_completo']))
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ya exista ese email
    			$this->User->invalidate('Nombre_completo','El usuario con ese nombre ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo guardarse. Verifique que lod datos son correctos e intente nuevamente.');
    		}
    		//se verifica si ese email ya se encuentra registrado
    		if ($this->User->findByEmail($this->data['User']['Email']))
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ya exista ese email
    			$this->User->invalidate('Email','El usuario con ese email ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo guardarse. Verifique que lod datos son correctos e intente nuevamente.');
    		}	 		
    		//se verifica si ese rfc ya se encuentra registrado
    		if ($this->User->findByRfc($this->data['User']['Rfc']))
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ya exista ese rfc
    			$this->User->invalidate('Rfc','EL usuario con ese RFC ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo guardarse. Verifique que lod datos son correctos e intente nuevamente.');
    		}	
			//se valida si el email, el username , el rfc y la palabra secreta no existe
    		else if(!$this->User->findByusername($this->data['User']['username']) &&
    				!$this->User->findByNombre_completo($this->data['User']['Nombre_completo']) &&
    				!$this->User->findByEmail($this->data['User']['Email']) && 
    				!$this->User->findByRfc($this->data['User']['Rfc']))				
    		{
    			//se crea un usuario con los datos que se ingresan
    			$this->User->create();
    			//se capturan y se guardan los datos del usuario
    			if ($this->User->save($this->request->data))  
    			{
    				$this->Session->setFlash('El Usuario ha sido guardado con &eacutexito');
    				//se hace una redireccion a index una vez que se guardaron los datos
    				$this->redirect(array('controller'=>'users','action' => 'lista_usuarios'));
    			}
    			else
    			{
    				$this->Session->setFlash('El Usuario no pudo guardarse. Verifique que los datos son correctos y trata nuevamente');
    			}
    		}
    			
    	}
    }
    //Funcion que permite editar usuarios
    public function edit($id = null) 
    {
    	$this->layout='tabla';
    	//secaptura el identificador del usuario a editar
    	$this->User->id = $id;
    	//consulta equivalente a realizar SELECT Email,username,rfc FROM users WHERE id=$id
    	//obtemos los datos del usuario actual que se quiere editar y se almacena en un array
    	$usuarioActual=$this->User->find('first',array(
    			'fields'=>array('User.Email,User.username,User.Rfc,User.Palabra_secreta,User.Nombre_completo'),
    			'conditions'=>array(
    					'User.id'=>$this->User->id))); 
    
    	//foreach($usuario as $usuarioActual) //obtemos los datos del usuario actual que se quiere editar
    	//se verifica si el usuario a editar no existe
    	if (!$this->User->exists())
    	{
    		$this->Session->setFlash('El usuario a editar no existe.');
    		$this->redirect(array('controller'=>'users','action' => 'lista_usuarios'));
    	}
    	//cargamos los datos con las reglas que se van a comparar en el modelo
    	//$this->User->set($this->request->data); 
    	if ($this->request->is('post') || $this->request->is('put'))  //se realiza una llamada por metodo post
    	{
    		//se muestran los campos invalidos segun las reglas del modelo
    		$this->User->invalidFields(); 
    	
    		//se valida si ya existe ese Email sin considerar el email del usuario que se esta editando actualmente
    		if ($this->User->findByUsername($this->data['User']['username']) && $this->data['User']['username']!=$usuarioActual['User']['username']  )
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese username ya exista
    			$this->User->invalidate('username','Ese Usuario ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo editarse. Por favor, intenta nuevamente.');
    		}
    		//se valida si ya existe ese el nombre del usuario sin considerar el nombre del usuario que se esta editando actualmente
    		if ($this->User->findByNombre_completo($this->data['User']['Nombre_completo']) && $this->data['User']['Nombre_completo']!=$usuarioActual['User']['Nombre_completo'])
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese nombre ya exista
    			$this->User->invalidate('Nombre_completo','El Usuario con ese nombre ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo editarse. Por favor, intenta nuevamente.');
    		}
    		//se valida si ya existe ese Email sin considerar el email del usuario que se esta editando actualmente
    		if ($this->User->findByEmail($this->data['User']['Email']) && $this->data['User']['Email']!=$usuarioActual['User']['Email']  )
    		{
    			//se invalida el campo muestra el mensaje del campo invalido en caso de que ya exista ese email
    			$this->User->invalidate('Email','El usuario con ese email ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo editarse. Por favor, intenta nuevamente.');
    		}
    		//se valida si ya existe ese rfc sin considerar el rfc del usuario que se esta editando actualmente
    		if ($this->User->findByRfc($this->data['User']['Rfc']) && $this->data['User']['Rfc']!=$usuarioActual['User']['Rfc'] )
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese rfc ya exista
    			$this->User->invalidate('Rfc','El usuario con ese RFC ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El usuario no pudo editarse. Por favor, intenta nuevamente.');
    		}
    		//se verifica si el username, el nombre, el email, y el rfc del usuario a editar no existe sin considerar el usuario actual
    		else if ((!$this->User->findByUsername($this->data['User']['username']) ||
    				$this->data['User']['username']==$usuarioActual['User']['username'] ) &&
    				(!$this->User->findByNombre_completo($this->data['User']['Nombre_completo']) ||
    						$this->data['User']['Nombre_completo']==$usuarioActual['User']['Nombre_completo']) &&
    				(!$this->User->findByEmail($this->data['User']['Email']) ||
    						$this->data['User']['Email']==$usuarioActual['User']['Email']) &&
    				(!$this->User->findByRfc($this->data['User']['Rfc']) ||
    						$this->data['User']['Rfc']==$usuarioActual['User']['Rfc'])
    		)
    		{
    			//se capturan y se guardan los datos de ese usuario
    			if ($this->User->save($this->request->data))
    			{
    				
    				$this->Session->setFlash('El usuario ha sido editado con &eacutexito');
    				$this->redirect(array('controller'=>'users','action' => 'lista_usuarios'));
    			} else {
    				$this->Session->setFlash('El usuario no pudo ser editado. Verifique que los datos son correctos y trata nuevamente.');
    			}
    		}
    	}
    	else
    	{
    		// Se capturan los datos del usuario a editar
    		$this->request->data = $this->User->read(); 
    	}
    }

    public function delete($id=null) {
    	
    	//Se establece la clase predeterminada y se establece el mensaje para setFlash
    	$class = 'flash_bad';
    	$msg   = 'Invalid List Id';

    	// Verifica que el id sea valido y que sea numerico
    	if($id!=null && is_numeric($id)) {
    		//Toma un elemento
    		$item = $this->User->read(null,$id);

    		//verifica si el elemento es valido
    		if(!empty($item)) {
    			//Se elimina el elemento
    			if($this->User->delete($id)) {
    				//se reinicia el autoincrement cada que se elimina un elemento
    				$this->User->query('ALTER TABLE `users` AUTO_INCREMENT=1 ');
    				$class = 'flash_good';
    				$msg   = 'El Usuario fue eliminado con exito';
    				
    			} else {
    				$this->Session->setFlash('El Usuario no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
    			}
    		}
    	}

    	//Salida JSON on AJAX request
    	if($this->RequestHandler->isAjax()) {
    		$this->autoRender = $this->layout = false; //evitar que renderice a otra vista
    		
    		print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
    		exit;   	
    	}
    	
    	$this->Session->setFlash($msg,'default',array('class'=>$class));
    	$this->redirect(array('controller'=>'users','action'=>'lista_usuarios'));
    	
    }
    
	/*
    //funcion que permite eliminar usuarios
    public function delete($id = null) 
    {
    	if (!$this->request->is('post')) //se realiza una llamada por metodo post
    	{
    		throw new MethodNotAllowedException();
    	}
    	//se obtiene el id del usuario a eliminar
    	$this->User->id = $id;
    	//se verifica si el usuario a eliminar no existe
    	if (!$this->User->exists()) 
    	{
    		throw new NotFoundException('El Usuario a eliminar no existe');
    	}
    	//se obtienen los datos del usuario que se va a eliminar
    	if ($this->User->delete()) 
    	{
    		$this->Session->setFlash('El usuario fue eliminado con exito');
    		//se reinicia el valor de autoincremento cada que se elimina un usuario
    		$this->User->query('ALTER TABLE `users` AUTO_INCREMENT=1 '); 
    		//se recarga la vista index una vez que se elimino el usuario para que se actualice la vista
    		//$this->render('index','tabla');
    		return $this->redirect(array('controller'=>'users','action' => 'index'));
    	}
    	else
    	{
    		$this->Session->setFlash('El usuario no pudo ser eliminado, verifica que sea un usuario valido');
    		//se recarga la vista index sin realizar ningun cambio
    		//$this->render('index','tabla');
    		return $this->redirect(array('controller'=>'users','action' => 'index'));
    	}
    }*/
	//Funcion que busca el email de algun usuario 
    public function email()
    {
    	$this->User->set($this->request->data); //cargamos los datos con las reglas que se van a comparar en el modelo
    	if ($this->request->is('post')) //se realiza una llamada por metodo post
    	{
    		$this->User->invalidFields(); //se muestran los campos invalidos segun las reglas del modelo
    		
    		if ($this->User->findByEmail($this->data['User']['Email']))//se valida si ya existe ese Email
    		{
    		     //consulta equivalente a realizar SELECT users.id,users.Palabra_secreta FROM users WHERE users.email=$email
    		     //obtenemos el id del usuario que se va a cambiar el password comparando su email y se almacena en un array
    			 $usuario=$this->User->find('first',array(
    					'fields'=>array('User.id,User.Palabra_secreta'),
    					'conditions'=>array(
    							'User.Email'=>$this->data['User']['Email']))); 
    			 //obtemos el valor del id del usuario actual que se quiere cambiar la contrase�a
    			foreach($usuario as $usuarioActual) 
    			{
    					//se redirecciona a la vista cambiar password pasandole el id del usuario que se quiere cambiar el password
    					$this->redirect(array('controller' => 'users', 'action' =>  'change_password',$usuarioActual['id'],$usuarioActual['Palabra_secreta']) );	
    			}
    					
    		}
    		else
    		{
    			//muestra el mensaje del campo invalido en caso de que no exista ese email
    			$this->User->invalidate('Email','El email solicitado no existe, ingrese otro'); 
    		}		
    	}
    
    }
    //Funcion que permite cambiar la contrase�a en caso de que el usuario no recuerde cual es la contrase�a
    public function change_password($id = null, $palabra_secreta)
    {
    	//Se captura el id del usuario que desea cambiar su password
    	$this->User->id= $id;
    	//cargamos los datos con las reglas que se van a comparar en el modelo
    	$this->User->set($this->request->data); 
    	if ($this->request->is('post') || $this->request->is('put'))  //se realiza una llamada por metodo post
    	{
    		//se muestran los campos invalidos segun las reglas del modelo
    		$this->User->invalidFields(); 
    		//se verifica si la palabra secreta ingresada es correcta y pertenece a la palabra secreta del usuario que desea cambiar su password 
    		if ($this->data['User']['Palabra_secreta']==$palabra_secreta)
    		{
    			//se capturan y se guardan los datos del password de ese usuario
    			if ($this->User->save($this->data))
    			{
    				$this->Session->setFlash('El cambio de password fue realizado con exito');
    				//se redirecciona a la vista login o de autentificacion de usuario una vez que se cambio el password
    				$this->redirect(array('controller'=>'users','action'=>'login'));
    			}
    			else
    			{
    				$this->Session->setFlash('El cambio de password no pudo realizarse. Verifique que la informacion es correcta y trata nuevamente.');
    			}
    		}
    		else
    		{
    			//muestra el mensaje del campo invalido en caso de que la palabra secreta no sea correcta
    			$this->User->invalidate('Palabra_secreta','La palabra secreta ingresada no es correcta, ingresa otra');
    		}

    	}
    }

	//funcion que permite logear a un usuario registrado
	public function login() 
	{
		$this->layout='login'; //llamar otro layout diferente al default
		//$this->layout('login'); //llamar otro layout diferente al default
		//se reinicia el contador de auto incremento cada que se muestra la vista de login
		$this->User->query('ALTER TABLE `users` AUTO_INCREMENT=1 '); 
		
		if ($this->request->is('post'))  //se realiza una llamada por metodo post
		{ 
			//se detecta si se trato de logear
			if ($this->Auth->login())  
			{ 
			
				//return $this->redirect($this->Auth->redirect(array('controller'=>'users','action'=>'index')));
				return $this->redirect($this->Auth->redirect()); //si los datos del usuario fueron correctos y se puedo logear se redirecciona a la vista
			}
			else
			{
			if (empty($this->data['User']['username']) ) 
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese username ya exista
    			$this->User->invalidate('username','El campo no puede estar vacio, necesita ingresar un usuername'); 
    			
    		}
    		if (empty($this->data['User']['password'])) 
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese username ya exista
    			$this->User->invalidate('password','El campo no puede estar vacio, necesita ingresar un password'); 
    		
    		}
    		else if (!empty($this->data['User']['username']) && !empty($this->data['User']['password']))
    		{
    			if (!$this->User->findByusername($this->data['User']['username']))
    			{
    				//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese username ya exista
    				$this->User->invalidate('username','Username Invalido, Favor de ingresar otro');
    		
    			}
    			//se verifica si el usuario con ese nombre ya se encuentra registrado
    			if (!$this->User->findBypassword($this->data['User']['password']))
    			{
    				//se invalida el campo y muestra el mensaje del campo invalido en caso de que ya exista ese email
    				$this->User->invalidate('password','Password Invalido, Favor de ingresar otro');
    				
    			}
    		}
				$this->Session->setFlash('Username o password invalido, verifica que los datos que escribio son correctos'); // en caso de que los datos no sean correctos se muestra este mensaje
			}			
		}
	}
	//funcion que permite hacer logout una vez que se logro acceder por medio del login
	public function logout() 
	{
		//se destruye la session
		$this->Session->destroy();
		//se desloguea el usuario
		return $this->redirect($this->Auth->logout());
	}
}
?>

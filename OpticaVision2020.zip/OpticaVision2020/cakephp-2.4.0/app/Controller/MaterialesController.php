<?php
class MaterialesController extends AppController
{
	public $name='Materiales';
	//Funcion que muestra la lista de pacientes registrados en el sistema
	public function index() {
		$this->Material->query('ALTER TABLE `materiales` AUTO_INCREMENT=1 ');
		$this->Material->recursive = 0;
		//$this->set('materiales', $this->paginate());
	
		$this->set('materiales', $this->Material->find('all'));
	}
}
?>

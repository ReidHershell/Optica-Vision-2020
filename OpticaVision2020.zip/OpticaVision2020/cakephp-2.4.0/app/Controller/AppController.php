<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */

class AppController extends Controller {
	var $helpers = array('Html','Form','Js');

	public $components = array(
			'Session',
			'Auth' => array(
					'loginRedirect' => array('controller' => 'users', 'action' => 'index'), //al hacer login se redirecciona a la vista index
					'logoutRedirect' => array('controller' => 'users', 'action' =>  'login'), //al hacer logout se redirecciona a la vista login
					//'authorize' => array('Controller') //linea que permite que se realicen los permisos de usuario
			)
	);
	//Funcion que filtra las acciones
	public function beforeFilter()
	{
		
		//$this->Auth->actionPath = 'controllers/';
		//se utiliza el modulo para autorizar permisos
		$this->Auth->authorize = 'controller';
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar
		$this->Auth->allow('login','change_password','email','logout');
		//se obtiene el usuario que logeo y se pasa a la vista
		$this->set('logged_in',$this->Auth->loggedIn());
		//se obtiene el usuario actual que ha logeado y se pasa a todas las vistas
		$this->set('current_user', $this->Auth->user());
		
	}
	/*
	//funcion que otorga los permisos a un usuario especifico de poder realizar cualquier accion
	public function isAuthorized($user) {
		
		// El usuario admin se le permite realizar cualquier accion
		if (isset($user['Rol']) && $user['Rol'] == 'admin') {
			return true;
		}
		else
		{
			$this->Session->setFlash('No estas autorizado de realizar esa accion.');
			
			// se niega cualquier accion a los usuarios que no sean admin
			return false;
		}
	}*/
}
?>




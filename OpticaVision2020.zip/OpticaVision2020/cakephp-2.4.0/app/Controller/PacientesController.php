<?php

class PacientesController extends AppController{
	
	var $nombre = 'Pacientes';	
	var $uses=array('Paciente','Record','Graduation'); //cargar otros modelos 
	//var $helpers = array('Js','Html', 'Form');
	var $components = array( 'RequestHandler' ); // variable que sirve para poder hacer request por medio de ajax

	public function beforeFilter() 
	{	
		parent::beforeFilter();	
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar
		
		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{		
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar		
			$this->Auth->allow('index','view','lista_pacientes','add','historial','graduacion');		
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','table');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{	
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit')
				{
					$this->Session->setFlash('No estas autorizado para realizar esta accion');
					$this->redirect(array('action'=>'lista_pacientes'));
				}			
			}
		}
		else
		{	
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}		
	}


	//Funcion que muestra la lista de pacientes registrados en el sistema
	public function index() {
		
		$this->Paciente->query('ALTER TABLE `pacientes` AUTO_INCREMENT=1 ');
		$this->Paciente->recursive = 1;
		$pacientes=$this->Paciente->find('all');
		$this->set('pacientes', $pacientes);
		if ($this->request->is('post'))
		{
			$nombre=$this->request->data['Paciente']['buscar'];
			//print_r($nombre);
			if (!empty($nombre))
			{
				//$buscar = $this->Record->findAll($this->postConditions($this->request->data['Record']['buscar']));
				$buscar_nombre=$this->Paciente->find('all',array('conditions'=>array('Paciente.Nombre_completo LIKE'=>'%'.$nombre.'%')));

				if (count($buscar_nombre)>0)
				{
					$this->set('pacientes',$buscar_nombre);
					//$this->render('Lista_pacientes','tabla');//se renderiza la vista
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Paciente->invalidate('buscar','No se encontraron coincidencias con ese nombre');
					
				}
			}
			else
			{

				//se invalida el campo en caso de que este vacio
				$this->Paciente->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
				
			}
			$this->render('Lista_pacientes','tabla');//se renderiza la vista index a otra vista
			
		}

	}
	//funcion que muestra la lista de pacientes
	public function Lista_pacientes()
	{
	
		$this->layout = 'tabla';
		$this->Paciente->query('ALTER TABLE `pacientes` AUTO_INCREMENT=1 ');
		$this->Paciente->recursive = 1;
		$pacientes=$this->paginate();
		$this->set('pacientes', $pacientes);
		if ($this->request->is('post'))
		{
			$nombre=$this->request->data['Paciente']['buscar'];;

				
			if (!empty($nombre))
			{
				
				$buscar_nombre=$this->Paciente->find('all',array('conditions'=>array('Paciente.Nombre_completo LIKE'=>'%'.$nombre.'%')));
				if (count($buscar_nombre)>0)
				{
					$this->set('pacientes',$buscar_nombre);
					//$this->render('index','tabla');//se renderiza la vista index con la vista agregar
				}
				else
				{
					//se invalida el campo en caso de que este vacio
					$this->Paciente->invalidate('buscar','No se encontraron coincidencias con ese nombre');
				
				}
			}
			else
			{
				//se invalida el campo en caso de que este vacio
				$this->Paciente->invalidate('buscar','El campo esta vacio, es necesario que escriba algo');
				
			}

		}
	}
	//Funcion que muestra la informacion detallada de un paciente registrado en el sistema
	public function view($id = null) {
		$this->layout='tabla';
		// se obtiene el id del paciente que se quiere mostrara su informacion detallada
		$this->Paciente->id=$id;
	
		if (!$this->Paciente->exists()) {
			throw new NotFoundException('El paciente solicitado no existe');
		}
		//se verifica si existe el id del paciente solicitado
		if (!$id) {
			$this->Session->setFlash('El id del paciente solicitado no existe');
			$this->redirect(array('controller'=>'pacientes','action' => 'index'));
		}
		//Se cargan en la vista los datos del paciente solicitado en caso de haber sido encontrado
		$this->set('paciente',$this->Paciente->read());

	}
	//funcion que permite agregar un paciente
	public function add()
	{
		$this->layout = 'tabla';
		//cargamos los datos con las reglas que se van a comparar en el modelo
		$this->Paciente->set($this->request->data);
		if ($this->request->is('post')) {
			//se muestran los campos invalidos segun las reglas del modelo
			$this->Paciente->invalidFields();
			//se valida si ya existe  ese paciente sin considerar el paciente que se esta editando actualmente
			if ($this->Paciente->findByNombre_completo($this->data['Paciente']['Nombre_completo']))
			{
				//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese paciente ya exista
				$this->Paciente->invalidate('Nombre_completo','Ese paciente ya se encuentra registrado, ingrese otro');
				$this->Session->setFlash('El Paciente no pudo guardarse. Verifique que los datos son correctos e intente nuevamente.');
			}
			else if (!$this->Paciente->findByNombre_completo($this->data['Paciente']['Nombre_completo']))
			{
				//se crea un paciente con los datos que se ingresan
				$this->Paciente->create();
				//se capturan y se guardan los datos del paciente
				if ($this->Paciente->save($this->request->data))
				{	
					$this->Session->setFlash('El Paciente ha sido guardado con &eacutexito');
					//se hace una redireccion a index una vez que se guardaron los datos
					return $this->redirect(array('controller'=>'pacientes','action' => 'Lista_pacientes'));
				}
				else
				{
					$this->Session->setFlash('El Paciente no pudo guardarse. Verifique que los datos son correctos y trata nuevamente');
				}
			}
			

		}
	}
	//Funcion que permite editar un paciente
	public function edit($id = null) 
	{
		$this->layout = 'tabla';
		//se captura el identificador del proveedor a editar
		$this->Paciente->id = $id;
		//consulta equivalente a realizar SELECT Nombre, Apellidos FROM pacientes WHERE id=$id
		//obtemos los datos del paciente actual que se quiere editar y se almacena en un array
		$pacienteActual=$this->Paciente->find('first',array(
				'fields'=>array('Paciente.Nombre_completo'),
				'conditions'=>array(
						'Paciente.id'=>$this->Paciente->id)));
		//se verifica si el paciente a editar no existe
		if (!$this->Paciente->exists())	
		{
			throw new NotFoundException('El paciente a editar no existe');
		}
		//cargamos los datos con las reglas que se van a comparar en el modelo
		$this->Paciente->set($this->request->data);
		if ($this->request->is('post') || $this->request->is('put')) {
			//se muestran los campos invalidos segun las reglas del modelo
			$this->Paciente->invalidFields();
			//se valida si ya existe  ese paciente sin considerar el paciente que se esta editando actualmente
    		if ($this->Paciente->findByNombre_completo($this->data['Paciente']['Nombre_completo']) && 
    				$this->data['Paciente']['Nombre_completo']!=$pacienteActual['Paciente']['Nombre_completo'])
    		{
    			//se invalida el campo y muestra el mensaje del campo invalido en caso de que ese paciente ya exista
    			$this->Paciente->invalidate('Nombre_completo','Ese paciente ya se encuentra registrado, ingrese otro');
    			$this->Session->setFlash('El Paciente no pudo editarse. Por favor, intenta nuevamente.');
    		}	
			// se verifica si ese no existe sin considerar los datos del paciente a editar
    		else if ((!$this->Paciente->findByNombre_completo($this->data['Paciente']['Nombre_completo']) || 
    				$this->data['Paciente']['Nombre_completo']==$pacienteActual['Paciente']['Nombre_completo'] ))
			{
				//se capturan y se guardan los datos de ese paciente
				if ($this->Paciente->save($this->request->data)){
					$this->Session->setFlash('El paciente ha sido editado con &eacutexito');
					return $this->redirect(array('controller'=>'pacientes','action' => 'Lista_pacientes'));
				} else {
					$this->Session->setFlash('El paciente no pudo ser editado. Verifique que los datos son correctos y trata nuevamente.');
				}
			}	
		} else {
			// Se capturan los datos del paciente a editar
			$this->request->data = $this->Paciente->read();
		}
	}
	//Funcion que permite eliminar un elemento
	function delete($id=null) {
		$this->layout = 'tabla';
		//Se establece la clase predeterminada y se establece el mensaje para setFlash
		$class = 'flash_bad';
		$msg   = 'Invalid List Id';
		// Verifica que el id sea valido y que sea numerico
		if($id!=null && is_numeric($id)) {
			//Toma un elemento
			$item = $this->Paciente->read(null,$id);
			//Verifica si el elemento es valido
			if(!empty($item)) {
				//Se elimina el elemento
				if($this->Paciente->delete($id)) {
					//se reinicia el autoincrement cada que se elimina un elemento
					$this->Paciente->query('ALTER TABLE `pacientes` AUTO_INCREMENT=1 ');
					$class = 'flash_good';
					$msg   = 'El Paciente fue elimino con exito';
				} else {
					$this->Session->setFlash('El Paciente no pudo eliminarse, revise que los datos son correctos y trata nuevamente');
				}
			}
		}
		//Salida JSON on AJAX request
		if($this->RequestHandler->isAjax())
		{
			$this->autoRender = $this->layout = false;
			print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
			exit;
		}
		//Se despliega el mensaje y se redirecciona
		$this->Session->setFlash($msg,'default',array('class'=>$class));
		$this->redirect(array('controller'=>'pacientes','action'=>'index'));
	}
	/*
	//funcion que permite eliminar un paciente
	public function delete($id = null) {
	
		if ($this->request->is('get')){ // se hace una llamada por metodo get
			throw new MethodNotAllowedException();
		}
		// se verifica si el id del paciente a eliminar no existe
		if (!$id) { 
			$this->Session->setFlash('El Id del paciente a eliminar no existe');
			$this->redirect(array('action' => 'index'));
		}
		//se captura el id del paciente a eliminar y posteriormente una vez encontrado su id este se elimina
		if ($this->Paciente->delete($id))
		{
			$this->Paciente->query('ALTER TABLE `pacientes` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('El paciente fue eliminado con exito');
			// se redirecciona a la vista principal donde se encuentra la lista de pacientes
			$this->redirect(array('action' => 'index'));
		}
		$this->Session->setFlash('El paciente no fue eliminado,  verifica que sea un paciente valido');
		// se redirecciona a la vista principal donde se encuentra la lista de pacientes
		$this->redirect(array('action' => 'index'));
	}*/

	


	

}
?>
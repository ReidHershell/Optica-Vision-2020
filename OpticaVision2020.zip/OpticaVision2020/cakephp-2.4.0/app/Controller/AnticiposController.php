<?php
class AnticiposController extends AppController
{
	var $name='Anticipos';
	/*
	public function beforeFilter()
	{
		parent::beforeFilter();
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar

		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar
			$this->Auth->allow('index','view','lista_pacientes');
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','add');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' ||  $this->params['action']=='add')
				{
					$this->redirect(array('action'=>'lista_pacientes'));
				}
			}
		}
		else
		{
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}
	}*/
	//Funcion que muestra la lista de anticipos
	public function index()
	{
		$this->Anticipo->query('ALTER TABLE `anticipos` AUTO_INCREMENT=1 ');
		$anticipos=$this->Anticipo->find('all');
		$this->set('anticipos',$anticipos);
	}
	//Funcion que muestra el detalle de un anticipo
	public function view($id=null)
	{
		$this->Anticipo->id=$id;
		
		if (!$this->Anticipo->exists()) {
			throw new NotFoundException('El anticipo solicitada no existe');
		}
		if (!$id) {
			$this->Session->setFlash('El id del anticipo solicitado no existe');
			$this->redirect(array('controller'=>'anticipos','action' => 'index'));
		}
		$this->set('anticipo',$this->Anticipo->read());
	}
	//funcion que crea un anticipo
	public function add()
	{
		if ($this->request->is('post')) {
			$this->Anticipo->create();
			if ($this->Anticipo->save($this->request->data)) {
				$this->Session->setFlash('El anticipo fue guardado con exito');
				$this->redirect(array('controller'=>'Anticipos','action' => 'index'));
			} else {
				$this->Session->setFlash('El anticipo no pudo guardarse, revise que los datos son correctos y trata nuevamente');
			}
		}
	}
	//funcion que permite editar un anticipo
	public function edit($id = null) {
		$this->Anticipo->id = $id;
	
		if (!$this->Anticipo->exists())	{
			throw new NotFoundException('El anticipo que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->Anticipo->save($this->request->data)){
				$this->Session->setFlash('El anticipo ha sido editada con exito');
				$this->redirect(array('controller'=>'anticipos','action' => 'index'));
			} else {
				$this->Session->setFlash('El anticipo no pudo ser editado, revise que los datos son correctos y trata nuevamente.');
			}
		}
		else {
			$this->request->data = $this->Anticipo->read();
		}
	}
	//funcion que permite eliminar un anticipo
	public function delete($id = null) {
		if ($this->request->is('get')){
			throw new MethodNotAllowedException();
		}
		if (!$id) {
			$this->Session->setFlash('El id del anticipo que se desea eliminar no existe');
			$this->redirect(array('controller'=>'anticipos','action' => 'index'));
		}
		if ($this->Anticipo->delete($id)) {
			$this->Anticipo->query('ALTER TABLE `anticipos` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('El anticipo fue eliminado con exito');
			$this->redirect(array('controller'=>'anticipos','action' => 'index'));
		}
		$this->Session->setFlash('El anticipo no pudo eliminarse, revise que los datos son correctos y trata nuevamente.');
		$this->redirect(array('controller'=>'anticipos','action' => 'index'));
	}
}
?>
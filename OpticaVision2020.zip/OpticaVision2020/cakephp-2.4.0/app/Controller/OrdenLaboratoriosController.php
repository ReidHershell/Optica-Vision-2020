<?php
class OrdenLaboratoriosController extends AppController{
	var $name='OrdenLaboratorios';
	/*
	public function beforeFilter()
	{
		parent::beforeFilter();
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar

		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar
			$this->Auth->allow('index','view','lista_pacientes');
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar pacientes
				$this->Auth->allow('edit','delete','add');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' || $this->params['action']== 'edit' ||  $this->params['action']=='add')
				{
					$this->redirect(array('action'=>'lista_pacientes'));
				}
			}
		}
		else
		{
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}
	}*/
	//Funcion que muestra la lista de ordenes de laboratorio
	public function index()
	{
		$this->OrdenLaboratorio->query('ALTER TABLE `orden_laboratorios` AUTO_INCREMENT=1 ');
		$ordenLaboratorios=$this->OrdenLaboratorio->find('all');
		$this->set('ordenLaboratorios',$ordenLaboratorios);
	}
	//Funcion que muestra el detalle de una orden de laboratorio
	public function view($id = null) {
	
	
		$this->OrdenLaboratorio->id=$id;
	
		if (!$this->OrdenLaboratorio->exists()) {
			throw new NotFoundException('La orden de laboratorio solicitada no existe');
		}
		if (!$id) {
			$this->Session->setFlash('El id de la orden de laboratorio solicitada no existe');
			$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
		}
		$this->set('ordenLaboratorio',$this->OrdenLaboratorio->read());
	}
	//funcion que genera una orden de laboratorio
	public function add()
	{
		if ($this->request->is('post')) {
			$this->OrdenLaboratorio->create();
			if ($this->OrdenLaboratorio->save($this->request->data)) {
				$this->Session->setFlash('La Orden de laboratorio fue guardada con exito');
				$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
			} else {
				$this->Session->setFlash('La Orden de laboratorio no pudo guardarse, revise que los datos son correctos y trata nuevamente');
			}
		}
	}
	//funcion que permite editar una orden de laboratorio
	public function edit($id = null) {
		$this->OrdenLaboratorio->id = $id;

		if (!$this->OrdenLaboratorio->exists())	{
			throw new NotFoundException('La Orden de laboratorio que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			if ($this->OrdenLaboratorio->save($this->request->data)){
				$this->Session->setFlash('La Orden de Laboratorio ha sido editada con exito');
				$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
			} else {
				$this->Session->setFlash('La Orden de Laboratorio no pudo ser editada, revise que los datos son correctos y trata nuevamente.');
			}
		 }
		 else {
	 		$this->request->data = $this->OrdenLaboratorio->read();
		 }
	}
	//funcion que permite elimninar una orden de laboratorio
	public function delete($id = null) {
		if ($this->request->is('get')){
			throw new MethodNotAllowedException();
		}
		if (!$id) {
			$this->Session->setFlash('El id de la Orden de Laboratorio que se desea eliminar no existe');
			$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
		}
		if ($this->OrdenLaboratorio->delete($id)) {
			$this->OrdenLaboratorio->query('ALTER TABLE `orden_laboratorios` AUTO_INCREMENT=1 ');
			$this->Session->setFlash('La Orden de Laboratorio fue eliminada con exito');
			$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
		}
		$this->Session->setFlash('La Orden de Laboratorio no pudo eliminarse, revise que los datos son correctos y trata nuevamente.');
		$this->redirect(array('controller'=>'OrdenLaboratorios','action' => 'index'));
	}
}
?>
<?php
class GraduationsController extends AppController{
   
    public $name = 'Graduations';
    var $uses = array('Graduation','Paciente'); 
    //var $helpers = array('Js','Html', 'Form');
    var $components = array( 'RequestHandler' ); // variable que sirve para poder hacer request por medio de ajax
 

	public function beforeFilter() 
	{	
		parent::beforeFilter();	
		//Se otorgan las acciones que cualquier usuario aunque no este logeado podra realizar
		
		//Se detecta si el usuario que trata de acceder se autentifico
		if ($this->Auth->loggedIn())
		{		
			//Se otorgan las acciones que cualquier usuario que se haya autentificado podra realizar		
			$this->Auth->allow('index','view','graduacion','add','escoger_actividad');		
			//se otorgan las acciones que solo podra realizar el administrados
			if ($this->Auth->user('Rol')=='admin')
			{
				//se permite que el administrador pueda editar, eliminar o agregar graduaciones
				$this->Auth->allow('edit','delete','table');
			}
			else if ($this->Auth->user('Rol')=='usuario')
			{	
				
				
				// Se verifica la accipon que el usuario quiere realizar.
				if($this->params['action']== 'delete' )
				{
					$this->Session->setFlash('No estas autorizado para realizar esta accion');
					$this->redirect(array('controller'=>'pacientes','action'=>'lista_pacientes'));
				}			
			}
		}
		else
		{	
			$this->Auth->authError='No estas autorizado de acceder a este sitio, es necesario autentificarte primero';
		}		
	}
    //Funcion que muestra todas las graduaciones registradas
    public function index() {
    	$this->layout = 'tabla';
    	$this->Graduation->query('ALTER TABLE `graduaciones` AUTO_INCREMENT=1 ');
    	$this->Graduation->recursive = 0;
    	$graduaciones=$this->paginate();
    	$this->set('graduations', $graduaciones);
    	
    }
    public function table($id = null)
    {
    	$this->layout = false;
    	$this->Graduation->id=$id;
    	if (!$this->Graduation->exists()) {
    		throw new NotFoundException('La graduacion solicitada no existe');

    	}
    	if (!$id) {
    		$this->Session->setFlash('El id de la graduacion solicitada no existe');
    		$this->redirect(array('action' => 'index'));
    	}
    	$this->set('graduation',$this->Graduation->read());
    	//se obtiene la lista de los nombres de los pacientes
    	$pacientes = $this->Graduation->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
    	//se cargan los nombres de los proveedores en la vista
    	$this->set('pacientes',$pacientes);
    }
    public function escoger_actividad($id)
    {
    	$this->layout='tabla';
    	
    	if ($this->request->is('post'))
    	{
    		
    		
    		if ($this->request->data['Graduation']['Actividad']=='Nueva Graduacion')
    		{
    			$paciente = $this->Paciente->Graduation->find('first',array(
    					'fields'=>array('Paciente.id'),
    					'conditions'=>array(
    							'Graduation.paciente_id'=>$id
    						)
    					)
    				);
    		
    			$this->redirect(array('controller'=>'graduations','action'=>'add',$paciente['Paciente']['id']));
    		}
    		else if ($this->request->data['Graduation']['Actividad']=='Ver graduaciones')
    		{
    			//print "id paciente ".$id;
    			
    			$paciente = $this->Paciente->Graduation->find('first',array(
    					'fields'=>array('Paciente.id'),
    					'conditions'=>array(
    							
    							'Graduation.paciente_id'=>$id
    					)
    				)
    			);
    			//print_r($paciente);
    			$this->redirect(array('controller'=>'graduations','action'=>'graduacion',$paciente['Paciente']['id']));
    		}
    		else
    		{
    			$this->Session->setFlash('Es necesario que seleccione una actividad');
    		}
    	}
    	
    }
  
	public function graduacion($id)
	{
		$this->layout = 'tabla';
		$graduacionEncontrada=$this->Graduation->find('count',array('fields'=>'paciente_id','conditions'=>array('paciente_id'=>$id)));
	
		if ($graduacionEncontrada)
		{
	
			$graduacion=$this->Graduation->find('all',array('conditions'=>array('paciente_id'=>$id)));
			$this->set('graduaciones',$graduacion);
		}
		else
		{
			$this->redirect(array('controller'=>'Graduations','action' => 'add',$id));
		}
	
	}
	//Funcion que muestra el detalle de una graduacion
	public function view($id = null) {
	   $this->layout = 'tabla';
	   
	   $this->Graduation->id=$id;
	   
	   if (!$this->Graduation->exists()) {
		  throw new NotFoundException('La graduacion solicitada no existe');
	   }
	   if (!$id) 
	   {
		   	$this->Session->setFlash('El id de la graduacion solicitada no existe');
		   	$this->redirect(array('action' => 'index'));
	   }
	   $this->set('graduation',$this->Graduation->read());
	   //se obtiene la lista de los nombres de los pacientes
	   $pacientes = $this->Graduation->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
	   //se cargan los nombres de los proveedores en la vista
	   $this->set('pacientes',$pacientes);
	}
	
	//funcion que agrega una graduacion
	public function add($paciente)
	{
		$this->layout = 'tabla';
		//se asigna el paciente
		$this->request->data['Graduation']['paciente_id']=$paciente;
		
		if ($this->request->is('post')) {
			
			//if(!$this->Graduation->findBypaciente_id($this->data['Graduation']['paciente_id']))
			//{
				$this->Graduation->create();
				if ($this->Graduation->save($this->request->data)) {
					$this->Session->setFlash('La graduaci&oacuten fue guardada con &eacutexito');
					$this->redirect(array('controller'=>'graduations','action' => 'graduacion',$this->data['Graduation']['paciente_id']));
				} else {
					$this->Session->setFlash('La graduaci&oacuten no pudo guardarse. verifique que los datos son correctos y trata nuevamente');
				}
			//}
			
			//else
			//{
				//$this->render('Lista_pacientes','tabla');
				//$this->redirect(array('controller'=>'graduations','action'=>'graduacion',$this->data['Graduation']['paciente_id']));
			//}
		}
		/*
		//se capturan los pacientes registrados
		$pacientes = $this->Graduation->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
		//se pasa la lista capturada de pacientes a la vista agregar
		$this->set('pacientes',$pacientes);*/
	}
	//funcion que edita una graduacion
	public function edit($id = null) {
		$this->layout = 'tabla';
		$this->Graduation->id = $id;
		
		if (!$this->Graduation->exists())	{
			throw new NotFoundException('La graduacion que se desea editar no existe');
		}
		if ($this->request->is('post') || $this->request->is('put')) {
			//$this->request->data['Graduation']['paciente_id']=$this->data['Graduation']['paciente_id'];
			if ($this->Graduation->save($this->request->data)){
				$this->Session->setFlash('La graduaci&oacuten ha sido editada con &eacutexito');
				$this->redirect(array('controller'=>'graduations','action'=>'graduacion',$this->data['Graduation']['paciente_id']));
			} else {
				$this->Session->setFlash('La graduaci&oacuten no pudo ser editada. Verifique que los datos son correctos y trata nuevamente.');
			}
		 }
		 else {
	 		$this->request->data = $this->Graduation->read();
	 		$this->set('graduation',$this->Graduation->read());
		 }
	
	 	//se capturan los pacientes registrados
	 	$pacientes = $this->Graduation->Paciente->find('list',array('fields'=>'Paciente.Nombre_completo'));
	 	//se pasa la lista capturada de pacientes a la vista editar
	 	$this->set('pacientes',$pacientes);
	}
	
	//Funcion que permite eliminar un elemento
	function delete($id=null) {
		//Se establece la clase predeterminada y se establece el mensaje para setFlash
		$class = 'flash_bad';
		$msg   = 'Invalid List Id';
		// Verifica que el id sea valido y que sea numerico
		if($id!=null && is_numeric($id)) {
			//Toma un elemento
			$item = $this->Graduation->read(null,$id);
			//Verifica si el elemento es valido
			if(!empty($item)) {
				//Se elimina el elemento
				if($this->Graduation->delete($id)) {
					//se reinicia el autoincrement cada que se elimina un elemento
					$this->Graduation->query('ALTER TABLE `graduaciones` AUTO_INCREMENT=1 ');
					$class = 'flash_good';
					$msg   = 'La Graduacion fue elimina con exito';
				} else {
					$this->Session->setFlash('La Graduacion no pudo eliminarse. Verifique que los datos son correctos y trata nuevamente');
				}
			}
		}
		//Salida JSON on AJAX request
		if($this->RequestHandler->isAjax())
		{
			$this->autoRender = $this->layout = false;
			print json_encode(array('success'=>($class=='flash_bad') ? FALSE : TRUE,'msg'=>"<p id='flashMessage' class='{$class}'>{$msg}</p>"));
			exit;
		}
		//Se despliega el mensaje y se redirecciona
		$this->Session->setFlash($msg,'default',array('class'=>$class));
		$this->redirect(array('controller'=>'graduations','action'=>'index'));
	}

}
?>
